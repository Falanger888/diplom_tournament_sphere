<?php
session_start();
require_once "verdan/connect.php";

if (!isset($_POST['login'])) {
    header("Location: search_users.php");
    exit;
}

$login = $connect->real_escape_string($_POST['login']); // Защита от SQL инъекций

// Поиск информации о пользователе в таблице characters
$sql = "SELECT * FROM characters WHERE `nickname` = '$login'";
$result = $connect->query($sql);

if ($result->num_rows > 0) {
    // Получаем строку с данными пользователя
    $row = $result->fetch_assoc();

    // Получаем значение столбца id_user
    $id_user = $row['id_users'];

}else {
    header("Location: search_users.php");
    exit;
}

$sqlPerson = "SELECT * FROM users WHERE id = $id_user";


$resultPerson = $connect->query($sqlPerson);
if ($resultPerson->num_rows > 0) {
    $row = $resultPerson->fetch_assoc();
    $img_avatar = $row['avatar'];

}



if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();


    // Запрос к таблице characters
    $sqlCharacters = "SELECT * FROM characters WHERE id_users = $id_user";

    $resultCharacters = $connect->query($sqlCharacters);

    // Дальнейшая обработка результата запроса к таблице characters
} else {
    header("Location: search_users.php");
    exit;
}




$sqlil = "SELECT `id`, `login` FROM `users` WHERE `id` = '$id_user'";
$resultil = $connect->query($sqlil);

if ($resultil && $resultil->num_rows > 0) {
    $rowil = $resultil->fetch_assoc();
    $id_user = $rowil['id'];

    $sqli = "SELECT * FROM team WHERE id_user = '$id_user'";
    $resultTeam = $connect->query($sqli);

    if ($resultTeam && $resultTeam->num_rows > 0) {
        $rowTeam = $resultTeam->fetch_assoc();
        $team = $rowTeam['name'];

        $sqli = "SELECT * FROM team WHERE name = '$team' AND rol = 'captain'";
        $resultImg = $connect->query($sqli);

        if ($resultImg && $resultImg->num_rows > 0) {
            $rowIMG = $resultImg->fetch_assoc();
            $img = $rowIMG['img'];
            // Теперь у вас есть изображение капитана команды
        } else {
            // Обработка случая, когда капитан команды не найден
        }
    } else {
        $team = '';
    }
} else {
    // Обработка случая, когда пользователь не найден
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Профиль игрока</title>
    <link rel="stylesheet" href="css/def_body.css">
    <style>
        .avatar-container {
            position: relative;
            width: 218px;
            height: 218px;
        }

        .avatar-container img {
            width: 100%;
            height: 100%;
        }

        .avatar-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            opacity: 0;
            transition: opacity 0.2s ease-in-out;
        }

        .avatar-container:hover .avatar-overlay {
            opacity: 1;
        }

        .avatar-overlay span {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 14px;
        }

        .avatar-overlay input {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            opacity: 0;
        }

        #avatarForm {
            cursor: pointer;
            width: auto;
        }

        .delete-pers-2 {
            text-align: center;
            display: inline-block;
            text-decoration: none;
            color: white;
            background-color: rgba(217, 217, 217, 0.4);
            padding: 5px;

            height: 30px;
            line-height: 10px;
            width: 30px;
            border-radius: 5px;
            font-size: 32px;
            cursor: pointer;
            transition: 0.5s;
            border: none;
            margin-left: 30px;
            margin-right: 30px;
        }

        .delete-pers-2:hover {
            background-color: rgba(217, 217, 217, 0.8);
            scale: 1.1;
            transition: 0.5s;
        }

        .button_uved {
            background-color: rgba(217, 217, 217, 0.4);
            width: 100px;
            font-size: 25px;
            cursor: pointer;
            transition: 0.5s;
            margin: 10px;
        }

        .button_uved:hover {
            background-color: rgba(217, 217, 217, 0.8);
            scale: 1.1;
            transition: 0.5s;
        }

        .margin-left {
            margin-left: 30px;
        }

        .notification>p {
            width: 80%;
        }

        .notification>form {
            width: auto;
        }

        .participants>div>p>a {
            color: white;
            text-decoration: none;
            transition: 0.5s;
        }

        .participants>div>p>a:hover {
            transition: 0.5s;
            color: gray;
        }

        .team-details {
            display: flex;
        }

        div {
            border: 0px solid black;
        }

        p {
            color: white;
            font-weight: 200;

        }

        .main-flex {
            margin: 0 auto;
            display: flex;
            width: 80%;

        }

        .profile-info {
            height: 250px;
            display: flex;
            align-items: center;
        }

        .profile-details {
            width: 500px;
            font-weight: 200;
            color: white;
            margin-left: 20px;
        }

        .profile-details p {
            font-weight: 200;
            color: white;
            margin: 0;
        }

        .profile-details .participants {
            display: flex;
            flex-direction: column;
        }

        .profile-details .participants div {
            display: flex;
            justify-content: space-between;
        }

        .profile-details .participants div p {
            margin: 0;
        }

        .logo-profile {
            width: 218px;
            height: 218px;
            object-fit: cover;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .new-pers {
            text-decoration: none;
            color: white;
            background-color: rgba(217, 217, 217, 0.4);
            padding: 5px;
            width: 20px;
            height: 20px;
            text-align: center;
            line-height: 20px;
        }

        .news {
            width: 80%;
            margin-left: 5%;
            display: flex;
            background-color: rgba(217, 217, 217, 0.5);
            color: white;
            align-items: center;
        }

        .scrollable-container {
            max-height: 250px;
            overflow: auto;
        }

        .scrollable-container::-webkit-scrollbar {
            width: 0;
        }

        table {
            color: white;
            font-weight: 200;
            width: 100%;
            border-collapse: collapse;
            border: 1px solid white;
        }

        .table-info {
            margin: 0 auto;
            width: 80%;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
            border: 0.5px solid white;
        }

        th {
            border: 0.5px solid white;
        }

        .shadows {
            background-color: rgba(217, 217, 217, 0.7);
            width: 145px;
            padding: 5px;
        }

        .shadows1 {
            margin-bottom: 10px;
            background-color: rgba(217, 217, 217, 0.7);
            width: 215px;
            padding: 5px;
        }

        .shadows2 {
            margin-left: 50px;
            margin-bottom: 10px;
            background-color: rgba(217, 217, 217, 0.7);
            width: 145px;
            padding: 5px;
        }

        /* Стиль информации команды */
        .team-info {
            width: 700px;
            margin: 0 auto;
            display: flex;
            height: 250px;
            padding-left: 50px;
            border-left: 1px solid grey;
        }

        .team-info img {
            width: 218px;
            height: 218px;
        }


        .participants {
            display: grid;
            grid-template-columns: auto auto;
            grid-gap: 5px;
        }

        .container-left {
            padding-right: 50px;
            height: 300px;
        }

        select {
            color: white;
            background-color: rgba(217, 217, 217, 0.4);
            border: 0;
            padding: 1px;
            border-radius: 5px;
            font-family: 'Montserrat Alternates', sans-serif;
            width: auto;
            height: auto;
            font-size: 24px;
        }

        select:disabled {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-color: transparent;
            border: none;
            color: inherit;
            cursor: default;
            opacity: 1;
        }

        option {
            color: grey;
            /* Устанавливаем серый цвет текста для опций */
        }
    </style>
</head>

<body>
    <?php
    include "header.php";
    ?>

    <div class="main-flex">
        <div class='container-left'>
            <p class='shadows'>Профиль</p>
            <div class="profile-info">

                <div class="avatar-container">
                    <img src="<?php echo $img_avatar; ?>" alt="картинка профиля">
                </div>

                <div class="profile-details">
                    <p class="name">Сервер</p>
                    <p class="email">Архетип</p>
                    <p class="phone">Никнейм</p>
                </div>
                <div class='profile-details-2'>
                    <div style='display:flex; height:39px'>
                    </div>

                    <p>
                        <select id="server-select" onchange="updateSelects(this.value)">
                            <?php // Заполнение селекта сервера
                            $id = 1;
                            while ($rowCharacter = $resultCharacters->fetch_assoc()) {
                                $characterServer = $rowCharacter['server'];
                                echo "<option value='$id'>$characterServer</option>";
                                $id++;
                            }
                            ?>
                        </select>
                    </p>
                    <p>
                        <select id="class-select" disabled>
                            <?php // Заполнение селекта класса
                            $resultCharacters->data_seek(0); // Сброс указателя результата на начало
                            $id = 1;
                            while ($rowCharacter = $resultCharacters->fetch_assoc()) {
                                $characterClass = $rowCharacter['class'];
                                echo "<option value='$id'>$characterClass</option>";
                                $id++;
                            }
                            ?>
                        </select>
                    </p>
                    <p>
                        <select id="nickname-select" disabled>
                            <?php // Заполнение селекта никнейма
                            $resultCharacters->data_seek(0); // Сброс указателя результата на начало
                            $id = 1;
                            while ($rowCharacter = $resultCharacters->fetch_assoc()) {
                                $characterNickname = $rowCharacter['nickname'];
                                echo "<option value='$id'>$characterNickname</option>";
                                $id++;
                            }
                            ?>
                        </select>
                    </p>
                </div>
            </div>
            <br>

        </div>
        <div class='container-right'>

            <p class='shadows2'>Команда</p>

            <div class="team-info">
                <div class="team-details">
                    <?php

                    $sql = "SELECT team.name, team.*, users.login 
FROM team 
JOIN users ON team.id_user = users.id 
WHERE team.name = '$team'";

                    $result = $connect->query($sql);

                    if ($result->num_rows > 0) {
                        // Вывод информации о команде
                        $row = $result->fetch_assoc();
                        $rol = $row['rol'];
                        $team = $row['name'];

                        // Аватар команды
                        $sqli = "SELECT * FROM team WHERE name = '$team' AND rol = 'captain'";
                        $resultImg = $connect->query($sqli);

                        if ($resultImg->num_rows > 0) {
                            $rowIMG = $resultImg->fetch_assoc();
                            $img = $rowIMG['img'];
                        } else {
                            echo "Капитан не найден";
                        }

                        echo '<div class="avatar-container ordinary-user">';
                        echo '<img src="' . $img . '" alt="Avatar">';
                        echo '</div>';

                        echo '<div>';
                        echo '<div class="margin-left"><p class="team-name">' . $team . '</p></div>';

                        echo '<div class="margin-left participants scrollable-container-uhastnik">';
                        echo '<div><p>Участники:</p></div><br>';

                        // Вывод участников
                        $result->data_seek(0); // Сбросить указатель результата обратно к началу
                    
                        while ($row = $result->fetch_assoc()) {
                            $userId = $row['id_user'];
                            $login = $row['login'];
                            $img = $row['img'];

                            echo '<div><p><a href="view_user.php?id=' . $userId . '">' . $login . '</a></p></div><br>';
                        }

                        echo '</div>';
                        echo '</div>';
                    } else {
                        echo "<p>У игрока нет команды.</p>";
                    }
                    ?>
                </div>
            </div>
            <br><br>

        </div>

    </div>
    <div class="table-info">

        <div class="game-history scrollable-container">

            <?php
            // Выполнение запроса
            $sqli = "SELECT * FROM `game_hystory` where id_user = '$id_user'";
            $resulti = $connect->query($sqli);

            // Проверка наличия записей
            if ($resulti->num_rows > 0) {
                echo '<table>';
                echo '<tr>';
                echo '<th>Категория</th>';
                echo '<th>Название</th>';
                echo '<th>Сервер</th>';
                echo '<th>Место</th>';
                echo '<th>Убийств</th>';
                echo '<th>Смертей</th>';
                echo '</tr>';

                while ($rowi = $resulti->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $rowi['cat'] . "</td>";
                    echo "<td>" . $rowi['name'] . "</td>";
                    echo "<td>" . $rowi['server'] . "</td>";
                    echo "<td>" . $rowi['mesto'] . "</td>";
                    echo "<td>" . $rowi['ubistv'] . "</td>";
                    echo "<td>" . $rowi['smertey'] . "</td>";
                    echo "</tr>";
                }

                echo '</table>';
            } else {
                echo "<br>";
                echo "<p>У игрока нет игры.</p>";
            }
            ?>
        </div>
    </div>
    <br><br><br>



    <script src="js/update_select.js"></script>
    <?php
    include "footer.php";
    ?>
</body>

</html>