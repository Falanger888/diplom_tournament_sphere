<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: Authorization.php");
    exit; 
}
$id_user = $_SESSION['user']['id'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Поддержка</title>
    <link rel="stylesheet" href="css/def_body.css">
    <style>
    .main-flex {
        display: flex;
        justify-content: space-around;
    }

    h1 {
        text-align: center;
        background-color: rgba(217, 217, 217, 0.7);
        width: 850px;
        margin: 0 auto;
        color: white;
    }

    p {
        color: white;
        font-weight: 200;
    }

    .shadows {
        background-color: rgba(217, 217, 217, 0.4);
        width: 190px;
        padding: 5px;
    }

    .shadows1 {
        background-color: rgba(217, 217, 217, 0.4);
        width: 350px;
        padding: 5px;
    }

    .shadows2 {
        background-color: rgba(217, 217, 217, 0.4);
        width: 200px;
        padding: 5px;
    }

    .shadows-qustion {
        font-weight: 200;
        padding: 5px;
       width: 870px;
        background-color: rgba(217, 217, 217, 0.4);
    }

    .scrollable-container {
        width: 900px;
        max-height: 500px;
        overflow: auto;
    }

    .scrollable-container::-webkit-scrollbar {
        width: 0;
    }

    input {
        color: white;
        background-color: rgba(217, 217, 217, 0.7);
        border: 0;
        border-radius: 21px;
        padding: 5px;
        font-family: 'Montserrat Alternates', sans-serif;
        width: 597px;
        height: 70px;
        font-size: 40px;
    }

    button {
        border: 0;
        font-family: 'Montserrat Alternates', sans-serif;
        font-size: 32px;
        width: 225px;
        border-radius: 11px;
        height: 100px;
        color: white;
        background-color: rgba(217, 217, 217, 0);
        transition: 0.5s;
        margin-left: 30px;

    }

    button:hover {
        transition: 0.5s;
        cursor: pointer;
        background-color: rgba(190, 194, 200, 0.4);
    }

    form {
        width: 900px;
    }

    body>div>div>p>a {

        text-decoration: none;
        color: white;
        transition: 0.5s;
    }

    body>div>div>p>a:hover {
        transition: 0.5s;

        text-decoration: none;
        color: grey;
    }

    .question>a {
        text-decoration: none;
        color: white;

    }

    .question>a:hover {
        color: gray;

    }
    </style>
</head>

<body>
    <?php
    include "header.php";
    ?>
    <div class="main-flex">
        <div>
            <p class="shadows">Поддержка</p>
            <br>
            <p class="shadows1">Популярные вопросы</p>
            <br>
            <div class='scrollable-container'>
                <div class="news">
                    <div>
                        <p class="question shadows-qustion">
                            Как принять участие в турнире? <br>
                            Чтобы принять участие в турнире, перейдите в соответствующую вкладку, выберите нужную
                            категорию и сервер, затем выберите персонажа и нажмите кнопку "Участвовать". После этого
                            подтвердите свое участие в турнире.
                        </p>
                    </div>

                </div>
                <br>
                <div class="news">
                    <div>
                        <p class="question shadows-qustion">Как найти команду? <br>
                            Чтобы найти команду, перейдите в соответствующую вкладку, выберите поиск команды, затем введите название команды в которую вы хотите попробывать вступить, а вствупите или нет решает командир команды.</p>
                    </div>

                </div>
                <br>
                <div class="news">
                    <div>
                        <p class="question shadows-qustion">Как найти игрока? <br>
                            Чтобы найти игрока, перейдите в соответсвующую вкладку, выберите никнейм игрока, затем вам выведиться его статистика.</p>
                    </div>
                </div>
                <br>
                <div style='border-bottom:1px solid grey;'></div>
                <br>
                <form action="verdan/support.php" method='POST'>
                    <p>Не нашли ответ на свой вопрос?<br>
                        Напишите нам!</p>
                    <br>
                    <input name='id' type="hidden" value='<?echo $id_user?>'>
                    <input name='description' type="text">
                    <button type="submit">Отправить</button>
                </form>

            </div>
        </div>
        <div>
            <p class="shadows2">Документы</p>
            <br>
            <p><a href="">Политика конф.</a></p>
            <p><a href="">Пользов. согл.</a></p>
            <p><a href="">Контакты</a></p>
        </div>
    </div>
    <br><br><br>
    <?php
    include "footer.php";
    ?>
</body>

</html>