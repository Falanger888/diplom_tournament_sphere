<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: Authorization.php");
    $_SESSION['message'] = 'Авторизуйтесь что бы перейти в профиль';
    exit;
}
require_once "verdan/connect.php";
$id_user = $_SESSION['user']['id'];





$sql = "SELECT * FROM users WHERE id = '$id_user'";
$result = $connect->query($sql);
$row = $result->fetch_assoc();


// Получение id пользователя
$login = $row['login'];

// Запрос к таблице characters
$sqlCharacters = "SELECT * FROM characters WHERE id_users = '$id_user'";

$resultCharacters = $connect->query($sqlCharacters);



// Команда
$sqlil = "SELECT * FROM team WHERE id_user = '$id_user'";
$resultil = $connect->query($sqlil);

if ($resultil->num_rows > 0) {
    $rowil = $resultil->fetch_assoc();
    $rol = $rowil['rol'];
    $team = $rowil['name'];

    $sqli = "SELECT * FROM team WHERE name = '$team' and rol ='captain'";
    $resultImg = $connect->query($sqli);
    $rowIMG = $resultImg->fetch_assoc();
    $img = $rowIMG['img'];
} else {
    $team = '';
}

?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Профиль игрока</title>
    <link rel="stylesheet" href="css/def_body.css">
    <link rel="stylesheet" href="css/profile.css">
</head>
<style>
.avatar-container {
    position: relative;
    width: 218px;
    height: 218px;
}

.avatar-container-2 {
    width: 218px;
    height: 218px;
}

.avatar-container img {
    width: 100%;
    height: 100%;
}

.avatar-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    opacity: 0;
    transition: opacity 0.2s ease-in-out;
}

.avatar-container:hover .avatar-overlay {
    opacity: 1;
}

.avatar-overlay span {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    font-size: 14px;
}

.avatar-overlay input {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
}

#avatarForm {
    cursor: pointer;
    width: auto;
}

.delete-pers-2 {
    text-align: center;
    display: inline-block;
    text-decoration: none;
    color: white;
    background-color: rgba(217, 217, 217, 0.4);
    padding: 5px;

    height: 30px;
    line-height: 10px;
    width: 30px;
    border-radius: 5px;
    font-size: 32px;
    cursor: pointer;
    transition: 0.5s;
    border: none;
    margin-left: 30px;
    margin-right: 30px;
}

.delete-pers-2:hover {
    background-color: rgba(217, 217, 217, 0.8);
    scale: 1.1;
    transition: 0.5s;
}

.button_uved {
    background-color: rgba(217, 217, 217, 0.4);
    width: 100px;
    font-size: 25px;
    cursor: pointer;
    transition: 0.5s;
    margin: 10px;
}

.button_uved:hover {
    background-color: rgba(217, 217, 217, 0.8);
    scale: 1.1;
    transition: 0.5s;
}

.margin-left {
    margin-left: 30px;
}

.notification>p {
    width: 80%;
}

.notification>form {
    width: auto;
}

.participants>div>p>a {
    color: white;
    text-decoration: none;
    transition: 0.5s;
}

.participants>div>p>a:hover {
    transition: 0.5s;
    color: gray;
}

.team-details {
    display: flex;
}

.container-right {
    width: 800px;
}
.flex-profile-details{
    display:flex;
}

.avatar_mobile{
    display:none;
}
.profile-details-2 >div>p{

    height:37px;
}



@media only screen and (max-width: 1700px) {

    .table-info {
        margin-left: 10px;
        padding-left: 50px;
        border-left: 1px solid grey;
        font-size: 18px;
    }

    .container-right {
        width: 700px;
    }

}
@media only screen and (max-width: 400px) {

.main-flex{
        display: block;
        width:100%;
}
.profile-info{
    display:block;
}
.shadows1{
    margin-left:10px;

}
.notification{
    margin-left:10px;
}
.container-left {
    padding-right: 0px;
    margin-left:10px;
}
.item {
  margin-bottom: 10px; /* Расстояние между элементами */
}

.profile-details,
.profile-details-2{
  flex-direction: row;
}

.avatar-container{
    display:none;
}
.profile-details{
    width:140px;
    height:180px;
}
.flex-profile-details{
    height:180px;
}
.profile-details,
.profile-details-2
{
    margin-left:0px;
}
.profile-details-2 p{
    font-size:18px;
    margin:2px;
}
.profile-details-2 >div>p{
    font-size:18px;
    margin:2px;
    height:18px;
}
select{
    font-size:18px;
    height:22px;
    margin:2px;
}
.profile-details p{
    font-size:18px;
    margin:4px;
}
.avatar_mobile{
    display:block;
    width:200px;
    height:200px;
    margin-top:10px;
}

.form-delete{
    margin-left:10px;
    width:30%;
}
    .container-right{
        margin-top:700px;
    }



.button_uved{
    width:30px;
    height:20px;
    font-size:12px;
    border-radius:5px;
    margin:5px;
    padding:5px;
}
.scrollable-container {
    max-height: 300px;
}
.team-details{
    display:block;
}
.margin-left{
    margin-top:20px;
}

.shadows3 {
    margin-top:150px;
    margin-left:10px;
}
.shadows2{
    margin-left:10px;
}
    .table-info{
        width:350px;
        border:none;
        padding-left:0px;
    }
    .container-right{
        width:300px;
    }
    .team-info{
        width:300px;
        border:none;
        padding-left:0px;
    }
    td,th{
        padding:4px;
        font-size:18px;
    }
}
</style>

<body>
    <?php
    include "header.php";
    ?>

    <div class="main-flex">
        <div class='container-left'>
            <div style='display:flex'>
                <p class='shadows'>Профиль</p>
                <button class="update_profile_button" onclick="toggleEditMode()">
                    <img class="update_profile" src="img/update/update.png" alt="">
                </button>
                <p class="messange">
                    <?php
                    if (isset($_SESSION['message'])) {
                        echo $_SESSION['message'];
                        unset($_SESSION['message']); // Очищаем переменную сообщения
                    }
                    ?>
                </p>
            </div>
            <img class='avatar_mobile' src="<?php echo $row['avatar']; ?>" alt="картинка профиля">
            <div class="profile-info">
                <form id="avatarForm" enctype="multipart/form-data">
                    <div class="avatar-container">
                        <img src="<?php echo $row['avatar']; ?>" alt="картинка профиля">
                        <div class="avatar-overlay">
                            <span>Изменить аватарку</span>
                            <input type="file" name="avatar" id="avatar" hidden>
                        </div>
                    </div>
                </form>
                <div class='flex-profile-details'>
                    
                    <div class="profile-details">
                    <p class="name">Логин</p>
                    <p class="name">Сервер</p>
                    <p class="email">Архетип</p>
                    <p class="phone">Никнейм</p>
                    <p class="phone">Почта</p>
                </div>
                <div class='profile-details-2'>
                    <div style='display:flex;'>
                        <p class='login-2'>
                            <?php echo $login; ?>
                        </p>
                        <button class="save-button" style="display: none;" onclick="saveProfileChanges()">✔</button>
                    </div>

                    <p>
                        <select id="server-select" onchange="updateSelects(this.value)">
                            <?php // Заполнение селекта сервера
                            $id = 1;
                            while ($rowCharacter = $resultCharacters->fetch_assoc()) {
                                $characterServer = $rowCharacter['server'];
                                echo "<option value='$id'>$characterServer</option>";
                                $id++;
                            }
                            ?>
                        </select>
                    </p>
                    <p>
                        <select id="class-select" disabled>
                            <?php // Заполнение селекта класса
                            $resultCharacters->data_seek(0); // Сброс указателя результата на начало
                            $id = 1;
                            while ($rowCharacter = $resultCharacters->fetch_assoc()) {
                                $characterClass = $rowCharacter['class'];
                                echo "<option value='$id'>$characterClass</option>";
                                $id++;
                            }
                            ?>
                        </select>
                    </p>
                    <p>
                        <select id="nickname-select" disabled>
                            <?php // Заполнение селекта никнейма
                            $resultCharacters->data_seek(0); // Сброс указателя результата на начало
                            $id = 1;
                            while ($rowCharacter = $resultCharacters->fetch_assoc()) {
                                $characterNickname = $rowCharacter['nickname'];
                                echo "<option value='$id'>$characterNickname</option>";
                                $id++;
                            }
                            ?>
                        </select>
                    </p>
                    <p class='email-2'>
                        <?php echo $row['email']; ?>
                    </p>
                </div>
                </div>
                

                <div>
                    <div style='display:flex'>
                        <form class='form-delete' action="verdan/delete_pers.php" method="POST">
                            <input id="server-delete" type="hidden" name="server" value="1">
                            <input id="nick-delete" type="hidden" name="nick" value="1">
                            <button class="delete-pers-2" type="submit">-</button>
                        </form>
                        <p class='button_new_pers'><a class="new-pers" href="#" onclick="openCharacterModal()">+</a></p>
                        <div id="character-modal1" class="modal">
                            <div class="modal-content1">
                                <form id="new_personag" action="verdan/add_pers.php" method="post"
                                    enctype="multipart/form-data">
                                    <input name="id" type="hidden" value='<? echo $id_user ?>'>
                                    <select class="select2" name='server' id="server" required>
                                        <option value="Луций">Луций</option>
                                        <option value="Корвус">Корвус</option>
                                        <option value="Фанем">Фанем</option>
                                        <option value="Шаеда">Шаеда</option>
                                        <option value="Ифнир">Ифнир</option>
                                        <option value="Ксанатос">Ксанатос</option>
                                        <option value="Тарон">Тарон</option>
                                        <option value="Рейвен">Рейвен</option>
                                        <option value="Нагашар">Нагашар</option>
                                    </select>
                                    <input id="nick_new_pers" type="text" name="nick" placeholder="Никнейм" required
                                        class="input">
                                    <span Style='font-size:14px;' id="nickError" style="color: white;"></span>
                                    <select class="select2" name="class" id="class" required>
                                        <option value="Танцор">Танцор</option>
                                        <option value="Лучник">Лучник</option>
                                        <option value="Маг">Маг</option>
                                        <option value="Воин">Воин</option>
                                        <option value="Целитель">Целитель</option>
                                        <option value="Стрелок">Стрелок</option>
                                    </select>
                                    <br>
                                    <button type="submit" class="new">Добавить нового персонажа</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <br><br>

            <?php
            $uved_notifications = "SELECT * FROM notifications WHERE login = '$login'";
            $result_uved_notifications = $connect->query($uved_notifications);

            $team_search_notifications = "SELECT * FROM `team_search` where `captain` = '$login' ";
            $result_team_search_notifications = $connect->query($team_search_notifications);

            if (($result_uved_notifications && $result_uved_notifications->num_rows > 0) || ($result_team_search_notifications && $result_team_search_notifications->num_rows > 0)) {
                echo "<p class='shadows1'>Уведомления</p>";
                echo "<div class='scrollable-container'>";

                if ($result_uved_notifications && $result_uved_notifications->num_rows > 0) {
                    while ($uved_row = $result_uved_notifications->fetch_assoc()) {
                        echo "<div class='notification'>";
                        echo "<div>";
                        echo "<p>" . $uved_row['name'] . "</p><br>";
                        echo "<p>" . $uved_row['description'] . "</p>";
                        echo "</div>";
                        if ($uved_row['name'] == 'Система') {
                            echo "<form action='verdan/uved_obrabotchik.php' method='post'>";
                            echo "<input type='hidden' name='notification_id' value='" . $uved_row['id'] . "'>";
                            echo "<input type='hidden' name='login' value='" . $login . "'>";
                            echo "<input type='hidden' name='name' value='" . $uved_row['name'] . "'>";
                            echo "<input class='button_uved' type='submit' name='result' value='OK'>";
                            echo "</form>";
                        } else {
                            echo "<form action='verdan/uved_obrabotchik.php' method='post'>";
                            echo "<div style='display:flex;'>";
                            echo "<input type='hidden' name='notification_id' value='" . $uved_row['id'] . "'>";
                            echo "<input class='button_uved' type='submit' name='result' value='Да'>";
                            echo "<input type='hidden' name='login' value='" . $login . "'>";
                            echo "<input type='hidden' name='name' value='" . $uved_row['name'] . "'>";
                            echo "<input class='button_uved' type='submit' name='result' value='Нет'>";
                            echo "</div>";
                            echo "</form>";
                        }
                        echo "</div>";
                        echo "<br>";
                    }
                }
                if ($result_team_search_notifications && $result_team_search_notifications->num_rows > 0) {
                    while ($uved_row = $result_team_search_notifications->fetch_assoc()) {
                        // Получаем login игрока по id из таблицы Users
                        $user_id = $uved_row['login'];
                        $id_zapsor = $uved_row['id'];
                        $user_query = "SELECT login FROM users WHERE id = $user_id";
                        $user_result = $connect->query($user_query);


                        if ($user_result && $user_result->num_rows > 0) {
                            $user_data = $user_result->fetch_assoc();
                            $player_login = $user_data['login'];
                        } else {
                            $player_login = 'Не найден';
                        }

                        echo "<div class='notification'>";
                        echo "<div>";
                        echo "<p>В вашу команду желает присоединиться игрок по имени " . $player_login . ". Пожалуйста, примите или отклоните его заявку.</p>";
                        echo "</div>";
                        echo "<form action='verdan/obrabotka_prinatya.php' method='post'>";
                        echo "<div style='display:flex;'>";
                        echo "<input type='hidden' name='id_user' value='" . $user_id . "'>";
                        echo "<input class='button_uved' type='submit' name='result' value='Да'>";
                        echo "<input type='hidden' name='id_zapros' value='" . $id_zapsor . "'>";
                        echo "<input type='hidden' name='name' value='" . $uved_row['name'] . "'>";
                        echo "<input class='button_uved' type='submit' name='result' value='Нет'>";
                        echo "</div>";
                        echo "</form>";
                        echo "</div>";
                    }
                }

                echo "</div>";
            } else {
                echo "<p class='shadows1'>Уведомления</p>";
                echo "<div class='notification'><p>У вас нет никаких уведомлений на данный момент</p></div>";
            }
            ?>
        </div>
        <div class='container-right'>
            <p class='shadows2'>Команда</p>

            <div class="team-info">
                <div class="team-details">
                    <?php

                    if (!empty($team)) {
                        $sql = "SELECT team.name, team.*, users.login 
        FROM team 
        JOIN users ON team.id_user = users.id 
        WHERE team.name = '$team'";

                        $result = $connect->query($sql);

                        if ($result->num_rows > 0) {
                            // Вывод информации о команде
                            $row = $result->fetch_assoc();
                            $rol = $row['rol'];
                            $team = $row['name'];

                            // Аватар команды
                            $sqli = "SELECT * FROM team WHERE name = '$team' AND rol = 'captain'";
                            $resultImg = $connect->query($sqli);

                            if ($resultImg->num_rows > 0) {
                                $rowIMG = $resultImg->fetch_assoc();
                                $img = $rowIMG['img'];
                            } else {
                                echo "Капитан не найден";
                            }

                            echo '<div class="avatar-container-2  ordinary-user">';
                            echo '<img src="' . $img . '" alt="Avatar">';
                            echo '</div>';

                            echo '<div>';
                            echo '<div class="margin-left"><p class="team-name">' . $team . '</p></div>';
                           
                            echo '<div class="margin-left participants scrollable-container-uhastnik scrollable-container-2">';
                            echo '<div><p>Участники:</p></div><br>';
                           

                            // Вывод участников
                            $result->data_seek(0); // Сбросить указатель результата обратно к началу
                    
                            while ($row = $result->fetch_assoc()) {
                                $userId = $row['id_user'];
                                $login = $row['login'];
                                $img = $row['img'];

                                echo '<div><p><a href="view_user.php?id=' . $userId . '">' . $login . '</a></p></div><br>';
                            }

                            echo '</div>';
                            echo '</div>';
                        } else {
                            echo "<p>У вас нет команды.</p>";
                        }
                    } else {
                        echo "<p>У вас нет команды.</p>";
                    }
                    ?>
                </div>
            </div>
            <br><br>
            <p class='shadows3'>История игр</p>
            <div class="table-info">

                <div class="game-history scrollable-container">

                    <?php
                    // Выполнение запроса
                    $sqli = "SELECT * FROM `game_hystory` where id_user = '$id_user'";
                    $resulti = $connect->query($sqli);

                    // Проверка наличия записей
                    if ($resulti->num_rows > 0) {
                        echo '<table>';
                        echo '<tr>';
                        echo '<th>Категория</th>';
                        echo '<th>Название</th>';
                        echo '<th>Сервер</th>';
                        echo '<th>Место</th>';
                        echo '<th>Побед</th>';
                        echo '<th>Поражений</th>';
                        echo '</tr>';

                        while ($rowi = $resulti->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $rowi['cat'] . "</td>";
                            echo "<td>" . $rowi['name'] . "</td>";
                            echo "<td>" . $rowi['server'] . "</td>";
                            echo "<td>" . $rowi['mesto'] . "</td>";
                            echo "<td>" . $rowi['ubistv'] . "</td>";
                            echo "<td>" . $rowi['smertey'] . "</td>";
                            echo "</tr>";
                        }

                        echo '</table>';
                    } else {
                        echo "<br>";
                        echo "<p>У вас нет игр.</p>";
                    }
                    ?>
                </div>
            </div>
        </div>

    </div>
    <br><br><br>
    <script src="js/profile.js"></script>
    <?php
    include "footer.php";
    ?>
</body>

</html>