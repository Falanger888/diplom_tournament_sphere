<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: Authorization.php");
    exit;
}

require_once 'verdan/connect.php';

// Получение id пользователя из сессии
$userId = $_SESSION['user']['id'];

// Подготовка SQL-запроса для проверки наличия пользователя в команде
$sql = "SELECT * FROM team WHERE id_user = $userId";
$result = mysqli_query($connect, $sql);

// Проверка наличия записи в таблице team
if (mysqli_num_rows($result) > 0) {
    // Запись существует, выполните перенаправление на нужную страницу
    header("Location: my_team.php");
    exit;
}

// Подготовка SQL-запроса для проверки наличия запроса в команду
$sqlLogin = "SELECT * FROM users WHERE id = $userId";
$resultLogin = mysqli_query($connect, $sqlLogin);
$rowLogin = mysqli_fetch_assoc($resultLogin);
$login = $rowLogin['login'];

$sqli = "SELECT * FROM team_search WHERE `login` = '$userId'";
$resulti = mysqli_query($connect, $sqli);

// Проверка наличия записи в таблице team_search
if (mysqli_num_rows($resulti) > 0) {
    // Запись существует, выполните перенаправление на нужную страницу
    header("Location: waiting_page.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Команды</title>
    <link rel="stylesheet" href="css/def_body.css">
    <link rel="stylesheet" href="css/team.css">
    <style>
    h1 {
        text-align: center;
        background-color: rgba(217, 217, 217, 0.4);
        width: 700px;
        padding: 5px;
        margin: 0 auto;
        font-weight: 100;
        font-size: 48px;
    }

    @media only screen and (max-width: 1700px) {
        h1 {
            width: 600px;
            font-size: 38px;
        }

        .create-team {
            width: 350px;
            font-size: 30px;
        }

        .search-team {
            width: 350px;
            font-size: 30px;
        }

        .main-flex>div>p {
            font-size: 25px
        }
    }


    @media only screen and (max-width: 1440px) {
        h1 {
            width: 500px;
            font-size: 32px;
        }

        .create-team {
            width: 300px;
            font-size: 28px;
        }

        .search-team {
            width: 300px;
            font-size: 28px;
        }

        .main-flex>div>p {
            font-size: 22px
        }
    }
     @media only screen and (max-width: 400px) {
        h1{
            width:340px;
            font-size:24px;
            margin-left:10px;
        }
        .main-flex{
            display:block;
                width: 90%;
        }
        .create-team {
            margin-top:30px;
        }
        .main-flex>div>p {
            width:300px;
        }
        .search-team{
            margin-top:30px;
        }
        .create-team{
            margin-right:0px;
        }
    }
    
    
    </style>
</head>

<body>
    <?php
    include "header.php";
    ?>
    <br><br>
    <h1>У вас пока нет команды</h1>
    <div class="main-flex">
        <div>
            <a href='create_team.php'><button class="create-team">Создать команду</button></a>
            <p>Создать новую команду, пригласить союзников</p>
        </div>
        <div>
            <a href="search_team.php"><button href='search_team.php' class="search-team">Найти команду</button></a>
            <p>Найти готовую команду по названию.</p>
        </div>

    </div>
    <br>
    <?php
    include "footer.php";
    ?>
</body>

</html>