<?php
session_start();

?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link rel="stylesheet" href="css/register.css">
</head>
<style>
     
 @media (max-width: 600px){
  .fon{
      margin-top:30px;
      width:300px;
      height:1050px;
  }
  .fon>a>img{
            width: 170px;
            margin-top: 35px;

        }
        input{
            width:230px;
            height:30px;
            font-size:18px;
            margin-right:0px;
            border-radius:10px;
        }
        button{
            margin-left:10%;
            margin-top:30px;
            font-size:24px;
            width:200px;
            height:50px;
            border-radius:10px;
        }
        p{
            margin-top:30px;
        font-size:18px;
        margin-left:20%;
        }
        label{
            font-size:24px;
        }
        
        .input-file+label{
            width:230px;
            height:30px;
             border-radius:10px;
                 margin-right: 0px;
        }
        .input-file+label{
           line-height: 30px;
        }
        select {
            width:240px;
            height:40px;
            font-size:18px;
            padding:5px;
            border-radius:10px;
        }
}
</style>
<body>
    <div class="fon">
        <a href="main.php"><img src="img/Лого.png" alt="logo"></a>
        <!-- Форма регистрации -->
        <form action="verdan/confirm_email.php" class="login-form" id="registration-form" method="POST" enctype="multipart/form-data">

            <p class='uspeh'>
                <?php
                if (isset($_SESSION['message'])) {

                    echo $_SESSION['message'];

                    unset($_SESSION['message']);
                }
                ?>
            </p>
            <!-- Логин -->
            <label for="login">Логин</label>
            <input name="login" type="text" id="login" required>
            <span id="login-error" style="color: white;"></span>
            <br>


            <!-- Аватар -->
            <label for="avatar">Аватар</label>
            <input name="avatar" type="file" class="input-file" id="fileInput" />
            <label for="fileInput" id="fileInputLabel">Выберите файл</label>
            <div name="avatar" class="input-file-2" id="selectedFileMessage" style="display: none;">Файл выбран: <span
                    id="fileName"></span></div>
            <br>


            <!-- Электронная почта -->
            <label for="email">Почта</label>
            <input name="email" type="email" id="email" required>
            <span id="error-msg" style="color: White; display: none;">формат email main@mail.ru</span>


            <!-- Никнейм -->
            <label for="nickName">Никнейм</label>
            <input name="nick" type="text" id="nickName" required>
            <span id="nickError" style="color: white;"></span>
            <br>


            <!-- Выбор сервера -->
            <label for=" server">Сервер</label>
            <select name='server' id="server" required>
                <option value="Луций">Луций</option>
                <option value="Корвус">Корвус</option>
                <option value="Фанем">Фанем</option>
                <option value="Шаеда">Шаеда</option>
                <option value="Ифнир">Ифнир</option>
                <option value="Ксанатос">Ксанатос</option>
                <option value="Тарон">Тарон</option>
                <option value="Рейвен">Рейвен</option>
                <option value="Нагашар">Нагашар</option>
            </select>


            <!-- Выбор класса -->
            <label for="class">Архетип</label>
            <select name="class" id="class" required>
                <option value="Танцор">Танцор</option>
                <option value="Лучник">Лучник</option>
                <option value="Маг">Маг</option>
                <option value="Воин">Воин</option>
                <option value="Целитель">Целитель</option>
                <option value="Стрелок">Стрелок</option>
            </select>



            <!-- Введение пароля -->
            <label for="password">Пароль</label>
            <input name='password' type="password" id="password" required>
            <span id="passwordError" style="color: white;"></span>

            <!-- Подтверждение пароля -->
            <label for="confirmPassword">Подтвердите пароль</label>
            <input name="config_password" type="password" id="confirmPassword" required>
            <span id="confirmPasswordError" style="color: white;"></span>


            <button type='submit'>Регистрация</button>
        </form>
        <p>Есть аккаунт? <a href="Authorization.php">Авторизуйтесь!</a></p>
    </div>
    <script src="js/validation_register.js"></script>
</body>

</html>