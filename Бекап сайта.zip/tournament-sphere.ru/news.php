<?php session_start();
require_once "verdan/connect.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/body.css">
    <link rel="stylesheet" href="css/news.css">
    <title>Новости</title>
</head>


<style>
/* Стили для модального окна */
.modal1 {
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.8);
}

.modal-content1 {
    background-color: rgba(217, 217, 217, 0.5);
    margin: 15% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 859px;
    text-align: center;
    font-size: 48px;
    border-radius: 50px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

input,
textarea {
    margin-top: 10px;
    color: white;
    background-color: rgba(217, 217, 217, 0.9);
    border: 0;
    border-radius: 21px;
    padding: 5px;
    font-family: 'Montserrat Alternates', sans-serif;
    width: 569px;
    height: 77px;
    font-size: 40px;
    text-align: center;
}

textarea {
    font-size: 25px;
    max-width: 569px;
    /* Замените значение на ширину модального окна */
    max-height: 200px;
    min-width: 569px;
    /* Замените значение на ширину модального окна */
    min-height: 50px;
    /* Замените значение на требуемую максимальную высоту */
}

/* Стили для placeholder */
input::placeholder,
textarea::placeholder {
    color: white;
}

.input-file {
    display: none;
}

.input-file+label {
    display: inline-block;
    background-color: rgba(217, 217, 217, 0.9);
    border: 0;
    border-radius: 21px;
    padding: 5px;
    font-family: 'Montserrat Alternates', sans-serif;
    width: 569px;
    height: 77px;
    font-size: 20px;
    text-align: center;
    line-height: 77px;
    cursor: pointer;

}

.input-file-2 {
    display: inline-block;
    background-color: rgba(217, 217, 217, 0.9);
    border: 0;
    border-radius: 21px;
    padding: 5px;
    font-family: 'Montserrat Alternates', sans-serif;
    width: 569px;
    height: 77px;
    font-size: 20px;
    text-align: center;
    line-height: 77px;
    cursor: pointer;
    margin-top: 10px;
    text-align: center;
}

#fileName,
#selectedFileMessage {
    color: white;
}

.flex-news {
    display: flex;
}

.new_news {
    margin-left: 20px;
    border: 0;
    font-family: 'Montserrat Alternates', sans-serif;
    font-size: 32px;
    width: auto;
    height: 62px;
    color: white;
    background-color: rgba(217, 217, 217, 0.4);
    transition: 0.5s;
    padding: 0px 10px;
}

.delete_news {
    padding: 5px;
    margin-right: 20px;
    margin-left: 20px;
    margin-top: 20px;
    border: 0;
    font-family: 'Montserrat Alternates', sans-serif;
    font-size: 15px;
    width: auto;
    height: auto;
    color: white;
    background-color: rgba(217, 217, 217, 0.4);
    transition: 0.5s;
}

button:hover {
    transition: 0.5s;
    cursor: pointer;
    background-color: rgba(190, 194, 200, 0.7);
}

.news {
    display: flex;
    align-items: flex-start;
    transition: 1s;
    width:80%;
}

.news-content {
    flex-grow: 1;
}

.admin-form {
    margin-left: auto;
}

.news-content>p {
    margin-top: 20px;
}

.new {
    margin-left: 20px;
    border: 0;
    font-family: 'Montserrat Alternates', sans-serif;
    font-size: 25px;
    width: 250px;
    height: 50px;
    color: white;
    background-color: rgba(217, 217, 217, 0.4);
    transition: 0.5s;
}

.news:hover {
    transition: 1s;
    background-color: rgba(217, 217, 217, 0.7);
}

.video-container {
    float: right;
    width: 30%;
    margin-bottom: 300px;
    margin-right:100px;
}

.video-container >h2,h3{
    color:white;
    font-size:25px;
    
}
.topic_video{
    font-size:35px;
    color:white;
}
</style>

<body>
    <?php
    include "header.php";
    ?>
    <br>
    <div class='flex-news'>
        <div class="text">
            <p>Лента новостей</p>

        </div>
        
        <div>

            <?php
            if (isset($_SESSION['user']['rol']) && $_SESSION['user']['rol'] == 'admin') {
                echo '<button class="new_news" onclick="openModal1()">Добавить новость</button>';
            }


            ?>
        </div>
    </div>
    
    <br>
    
 


    <div>
        <?php include "verdan/news.php"; ?>
    </div>



    </div>
    <d iv id="modal1" class="modal">
        <div class="modal-content1">
            <form action="verdan/add_news.php" method="post" enctype="multipart/form-data">
                <!-- Ваши поля формы для добавления новости -->
                <input type="text" name="title" placeholder="Заголовок" required class="input-field">
                <br>
                <textarea name="description" placeholder="Описание" required class="textarea-field"></textarea>
                <br>
                <input name="avatar" type="file" class="input-file" id="fileInput" />
                <label for="fileInput" id="fileInputLabel" style="color:white;">Выберите файл</label>
                <div name="avatar" class="input-file-2" id="selectedFileMessage" style="display: none;">Файл выбран:
                    <span id="fileName"></span>
                </div>
                <br>
                <button type="submit" class="new">Новая новость</button>
            </form>
        </div>



        <script src="js/validation_img_news.js"></script>


        <br><br>
        <?php
    include "footer.php";
    ?>
</body>

</html>