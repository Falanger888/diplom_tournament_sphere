<?php
// Массивы в массиве данных, данный в задании
$data = [
    ['Иванов', 'Математика', 5],
    ['Иванов', 'Математика', 4],
    ['Иванов', 'Математика', 5],
    ['Иванов', 'Изо', 5],
    ['Петров', 'Математика', 5],   // Тут была опечатка, Петров был не в кавычках, (может быть это преполагало задание).
    ['Сидоров', 'Физика', 4],
    ['Иванов', 'Физика', 4],
    ['Петров', 'ОБЖ', 4],
];

// Сортируем массивы по фамилии для дальнейших действий
usort($data, function ($a, $b) {
    return strcmp($a[0], $b[0]);
});





// Получаем массив уникальных предметов
$uniqueSubjects = [];

foreach ($data as $row) {
    if (!in_array($row[1], $uniqueSubjects)) {
        $uniqueSubjects[] = $row[1];
    }
}



// Верстаем таблицу
echo '<table>';
echo '<th></th>';
// Через цикл выводим интересующие нас заголовки столбцов
foreach ($uniqueSubjects as $row) {

    echo '<th>' . $row . '</th>';
}



foreach ($data as $dat) {
    $student = $dat[0];
    $object = $dat[1];
    $score = $dat[2];

    echo '<tr><td>' . $student . '</td>';
    echo '<td>' . $score . '</td>';
    echo '<td>' . $score . '</td>';
    echo '<td>' . $score . '</td></tr>';
}

echo '</table>';