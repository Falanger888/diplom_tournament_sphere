<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Категории турниров</title>
    <link rel="stylesheet" href="css/def_body.css">
</head>
<style>
body {
    width: 100%;
}

.main-flex {
    color: white;
    font-weight: 200;
    display: flex;
    justify-content: space-around;
}

.cat {
    background-color: rgba(217, 217, 217, 0.4);
    width: 425px;
    height: 425px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.table-cat {

    border-radius: 5px;
    font-weight: 300;
    height: 75px;
    width: 400px;
    border: 0;
    background-color: rgba(217, 217, 217, 0.4);
    color: white;
    font-size: 25px;
    transition: 0.5s;
    cursor: pointer;
    font-family: 'Montserrat Alternates', sans-serif;
}

button:hover {
    transition: 0.5s;
    background-color: rgba(217, 217, 217, 1);
}

.img_1,
.img_2,
.img_3 {
    overflow:hidden;
    width: 350px;
    height: 350px;
    background: rgba(217, 217, 217, 0.8);
    display: flex;
    justify-content: center;
    align-items: end;


}

.img_1,
.img_2 {
    background-size: contain;
    background-position: center;
    background-repeat: no-repeat;
    background-size: 100%;
     transition: transform 2s;
}

.img_1:hover,
.img_2:hover {
    background-size: 150%;
    animation: increaseSize 10s infinite alternate;
}

@keyframes increaseSize {
    0%, 100% {
        background-size: 100%;
    }
    50% {
        background-size: 150%;
    }
}




.img_1 {
    background-image: url('img/turnir/1vs1.png');
}

.img_2 {
    background-image: url('img/turnir/2vs2.png');
}

button {
    padding: 3px;
    transition: 0.5s;
    height: 50px;
    background-color: rgba(217, 217, 217, 0.6);
    border: none;
    width: 120px;
    margin: 5px;
    font-size: 32px;
    color: white;
    cursor: pointer;
}

.main-buuton-bottom {
    margin-top: 150px;
    display: flex;
    justify-content: space-around;
    align-items: center;
    flex-direction: column;

}
.cat{
     transition:0.5s;
}

.cat:hover{
    background-color: rgba(217, 217, 217, 1);
    transition:0.5s;
}

@media only screen and (max-width: 1700px) {

    .cat {
        width: 325px;
        height: 325px;

    }

    .img {

        width: 280px;
        height: 280px;


    }

    .img_1,
    .img_2,
    .img_3 {

        width: 270px;
        height: 270px;
        display: flex;
        justify-content: center;
        align-items: end;


    }


    .main-buuton-bottom {
        margin-top: 50px;


    }


}

@media only screen and (max-width: 1440px) {
    .cat {
        width: 225px;
        height: 225px;

    }

    .img_1,
    .img_2,
    .img_3 {

        width: 175px;
        height: 175px;
        display: flex;
        justify-content: center;
        align-items: end;


    }

    .img {

        width: 190px;
        height: 190px;


    }

    .main-buuton-bottom {
        margin-top: 50px;


    }
}
@media only screen and (max-width: 1100px) {
    .main-flex {
  color: white;
  font-weight: 200;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

.cat_2{
    margin-top:20px;
}
.cat_3{
    margin-top:20px;
}
.table-cat {
        width:200px;


    }
}
</style>


<body>
    <?php
    include "header.php";
    ?>
    
    
    <div class="main-flex">
        <div class='cat_1'>
            <div class="cat">
                <div class="img_1">
                    
                    <form action="turnir_server.php" method="POST">

                        <input type="text" name="cat_tur" hidden value="1 VS 1">
                        <button type='submith'>1 VS 1</button>
                    </form>
                </div>
            </div>
        </div>

        <div class='cat_2'>
            <div class="cat">
                <div class="img_2">
                    <form action="turnir_server.php" method="POST">
                        <input type="text" name="cat_tur" hidden value="2 VS 2">
                        <button type='submith'>2 VS 2</button>
                    </form>
                </div>
            </div>
        </div>
        <div class='cat_3'>
            <div class="cat">
                <div class="img_3">
                    <form action="turnir_server.php" method="POST">
                        <input type="text" name="cat_tur" hidden value="5 VS 5">
                        <button type='submith'>5 VS 5</button>
                    </form>

                </div>
            </div>
        </div>




    </div>

    <div class='main-buuton-bottom'>
        <a href="turnir_table.php"><button class="table-cat">Турниры</button></a>
    </div>


    <br><br><br><br>
    <?php
    include "footer.php";
    ?>
</body>

</html>