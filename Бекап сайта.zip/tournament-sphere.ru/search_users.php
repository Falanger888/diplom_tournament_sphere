<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Поиск команды</title>
    <link rel="stylesheet" href="css/def_body.css">

</head>
<style>
h1 {
    color: white;
    font-size: 48px;
}

h1 {
    font-weight: 300;
    text-align: center;
    margin-top: auto;
    background-color: rgba(217, 217, 217, 0.4);
    width: 410px;
    margin: 0 auto;
    padding: 10px;
}

label {
    font-family: 'Montserrat Alternates', sans-serif;
    font-size: 32px;
    margin-top: 40px;
    font-weight: 200;
}

form {
    height: 350px;
    margin: 0 auto;
    width: 640px;
    background-color: rgba(217, 217, 217, 0.4);
    display: flex;
    flex-direction: column;
    align-items: center;

}

input {
    background-color: rgba(217, 217, 217, 0.4);
    color: white;
    width: 483px;
    margin-top: 50px;
    border: 0;
    border-radius: 11px;
    height: 59px;
    font-family: 'Montserrat Alternates', sans-serif;
    padding: 5px;
    font-size: 30px;

}

button {
    margin-top: 40px;
    border-radius: 5px;
    padding: 3px;
    font-weight: 300;
    height: 70px;
    width: 200px;
    border: 0;
    background-color: rgba(217, 217, 217, 0);
    color: white;
    font-size: 25px;
    transition: 0.5s;
    cursor: pointer;
    font-family: 'Montserrat Alternates', sans-serif;
}

button:hover {
    cursor: pointer;
    transition: 0.5s;
    background-color: rgba(217, 217, 217, 0.5);
}


label {
    color: white;
}

@media only screen and (max-width: 400px) {
        h1{
            width:300px;
            font-size:24px;
        }
        form{
            width:350px;
            height:350px;
        }
        input{
            width:300px;
        }
        label{
            font-size:20px;
        }
        body>div>p{
            width:300px;
            font-size:18px;
        }
    }
</style>

<body>
    <?php
    include "header.php";
    ?>
    <h1>Поиск игроков</h1>
    <br><br>
    <div>
        <form action="users_info.php" method="POST">
            <label for="">Введите никнейм игрока</label>
            <input name='login' type="text">
            <button type="submit">Найти</button>
        </form>
    </div>
<br><br><br><br><br>
    <?php
    include "footer.php";
    ?>
</body>

</html>