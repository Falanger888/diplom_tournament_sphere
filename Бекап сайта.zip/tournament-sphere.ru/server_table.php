<?php
session_start();
require_once "verdan/connect.php";

// Проверяем наличие данных в сессии
if (isset($_SESSION['cat_tur'], $_SESSION['server'])) {
    $cat_tur = $_SESSION['cat_tur'];
    $server = $_SESSION['server'];
} elseif (isset($_POST['cat_tur'], $_POST['server'])) {
    $cat_tur = $_POST['cat_tur'];
    $server = $_POST['server'];
} else {
    $_SESSION['message'] = "Данные не найдены. Пожалуйста, попробуйте снова.";
    header("Location: turnir_cat.php");
    exit();
}

if (isset($_SESSION['user']['id'])) {
    $id_user = $_SESSION['user']['id'];

    // Ваш код, который зависит от наличия $_SESSION['user']['id']
} else {
    // Обработка случая, когда 'user' отсутствует в сессии
}

// Защита от SQL инъекций
$query = $connect->prepare("SELECT * FROM `participants` WHERE `cat` = ? AND `server` = ?");
$query->bind_param("ss", $cat_tur, $server);
$query->execute();
$result = $query->get_result();

// Удаляем данные из сессии после использования
unset($_SESSION['cat_tur']);
unset($_SESSION['server']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Таблица сервера
        <? echo $server ?>
    </title>
    <link rel="stylesheet" href="css/def_body.css">
</head>
<style>
h1 {
    display: inline-block;
    color: white;
    background-color: rgba(217, 217, 217, 0.4);
    padding: 10px;
    font-size: 48px;
}

body {
    width: 100%;
}

.main-flex {
    width: 95%;
    margin: 0 auto;
    color: white;
    font-weight: 200;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    flex-direction: column;
}



.cat {
    width: 30%;
    margin-bottom: 20px;
}

.cat {
    background-color: rgba(217, 217, 217, 0.4);
    width: 425px;
    height: 425px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.table-cat {

    border-radius: 5px;
    font-weight: 300;
    height: 70px;
    width: 200px;
    border: 0;
    background-color: rgba(217, 217, 217, 0.4);
    color: white;
    font-size: 25px;
    transition: 0.5s;
    cursor: pointer;
    font-family: 'Montserrat Alternates', sans-serif;
}

button:hover {
    transition: 0.5s;
    background-color: rgba(217, 217, 217, 0.8);
}

.img {

    width: 350px;
    height: 350px;
    background: rgba(217, 217, 217, 0.8);
    display: flex;
    justify-content: center;
    align-items: end;


}

button {
    padding: 3px;
    transition: 0.5s;
    height: 50px;
    background: none;
    border: none;
    width: 350px;
    margin: 5px;
    font-size: 32px;
    color: white;
    border-radius: 5px;
    cursor: pointer;
    font-family: 'Montserrat Alternates', sans-serif;
}

.main-buuton-bottom {
    margin-top: 150px;
    display: flex;
    justify-content: space-around;
    align-items: center;
    flex-direction: column;

}

table {
    width: 800px;
    margin: 0 auto;
    color: white;
    font-weight: 200;

    border-collapse: collapse;
    border: 1px solid white;
}


th,
td {
    padding: 8px;
    text-align: left;
    border: 0.5px solid white;
}

th {
    border: 0.5px solid white;
}


.scrollable-container {
    margin: 0 auto;
    width: 80%;
    max-height: 350px;
    overflow: auto;
}

.scrollable-container::-webkit-scrollbar {
    width: 0;
}

@media only screen and (max-width: 1600px) {



    .scrollable-container {
        max-height: 350px;

    }
}

@media only screen and (max-width: 1200px) {


    .scrollable-container {
        max-height: 250px;

    }
}

/* Кастом модалка */
.unique-modal {
    color: white;
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.4);
    /* Полупрозрачный фон */
}

.unique-modal-content {
    background-color: rgba(217, 217, 217, 1);
    margin: 15% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 700px;
    height: auto;
    font-size: 48px;
    border-radius: 50px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

.messange {
    color: white;
    margin-left: 35%;
    padding-bottom: 10px;
}

.font-size-20 {
    font-size: 20px;
}

.container-zag {
    text-align: center;
}


@media only screen and (max-width: 400px) {

        h1 {
            font-size:24px;
        }

       .scrollable-container {
            max-height: 250px;
            width:350px;
            font-size:12px;
            margin-left:5px;

        }
        td,th{
            padding:4px;
        }
        th{
            width:30px;
        }
        table{
            width:300px;
        }
        
        .unique-modal-content{
            width:300px;
        }
        .uhastnik_tur{
            width:200px;
            font-size:20px;
        }
        p{
            font-size:24px;
        }
        .unique-modal-content {
            font-size:20px;
        }
    }
</style>



<body>
    <?php
    include "header.php";
    ?>
    <div class="container-zag">
        <h1>Турнир
            <? echo $cat_tur ?> |
            <? echo $server ?>
        </h1>
    </div>


    <br><br>
    <div>
        <p class="messange">
            <?php
            if (isset($_SESSION['message2'])) {
                echo $_SESSION['message2'];
                unset($_SESSION['message2']); // Очищаем переменную сообщения
            }
            ?>
        </p>
    </div>

    <div class="main-flex">
        <div class='scrollable-container'>
            <table>
                <tr>
                    <th>Никнейм</th>
                    <th>Класс</th>
                    <th>Команда</th>
                </tr>
                <?php
                // SQL-запрос для получения данных из базы данных
                $query = "SELECT * FROM participants WHERE cat = '$cat_tur' AND server = '$server'";

                $result = $connect->query($query);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $id_char = $row['id_haracters'];
                        $id_user_team = $row['id_user'];

                        // SQL-запрос для получения имени команды из таблицы "team" по id_user
                        $query_team = "SELECT name FROM team WHERE id_user = $id_user_team";
                        $result_team = $connect->query($query_team);

                        if ($result_team->num_rows > 0) {
                            $row_team = $result_team->fetch_assoc();
                            $team_name = $row_team['name'];
                        } else {
                            $team_name = "Нет";
                        }

                        // Получение информации о классе и никнейме из таблицы characters по id_characters
                        $query_char = "SELECT class, nickname FROM characters WHERE id = $id_char";
                        $result_char = $connect->query($query_char);

                        if ($result_char->num_rows > 0) {
                            $row_char = $result_char->fetch_assoc();
                            $class = $row_char['class'];
                            $nickname = $row_char['nickname'];

                            echo "<tr>
                <td>$nickname</td>
                <td>$class</td>
                <td>$team_name</td>
            </tr>";
                        } else {
                            echo "<tr><td colspan='3'>Данные о персонаже не найдены</td></tr>";
                        }
                    }
                } else {
                    echo "<tr><td colspan='3'>Никто не зарегистрировался.</td></tr>";
                }
                ?>
            </table>
        </div>

        <div style='display:flex; margin:0 auto; justify-content: space-around; margin-top: 100px;'>

            <?php

            if (isset($_SESSION['user'])) {
                echo "<button onclick='openUniqueModal()'>Участвовать</button>";
            }
            ?>
        </div>
    </div>
    <br><br><br>
    <?php
    include "footer.php";
    ?>


    <?php


    if ($cat_tur == '1 VS 1') {
        // Блок для категории 1v1
        ?>
    <style>
    .uhastnik_tur {
        background-color: rgba(128, 128, 128, 0.5);
        margin: 0 auto;
        display: block;
        text-align: center;
    }

    .uhastnik_tur:hover {
        scale: 1.1;
        background-color: rgba(128, 128, 128, 1);

    }

    .checkbox-custom {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        display: inline-block;
        position: relative;
        background-color: none;
        border: 1px solid white;
        border-radius: 100%;
        color: #888;
        padding: 12px;
        cursor: pointer;
        margin-right: 10px;
    }

    .checkbox-custom:checked::before {
        content: '\2714';
        display: block;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        font-size: 18px;
        color: #fff;
        background-color: #888;
        border-radius: 50%;
        width: 24px;
        height: 24px;
        text-align: center;
        line-height: 24px;
    }
    </style>
    <div id="uniqueModal" class="unique-modal">
        <div class="unique-modal-content">
            <form id="characterForm" method="post" action="verdan/add_uhastnik_tur.php">
                <p>Выберите персонажа:</p><br>
                <?php
                    $sql = "SELECT * FROM characters WHERE id_users = '$id_user' AND `server` = '$server'";
                    $result = $connect->query($sql);

                    if ($result->num_rows > 0) {
                        $first = true;
                        while ($row = $result->fetch_assoc()) {
                            $checked = $first ? 'checked' : ''; // Устанавливаем checked для первого элемента
                            echo "<input class='checkbox-custom' type='checkbox' id='char_" . $row['id'] . "' name='character' value='" . $row['id'] . "' $checked onchange='uncheckAll(this)' require>";
                            echo "<label for='char_" . $row['id'] . "'>" . $row['nickname'] . "</label><br>";
                            $first = false;
                        }
                        echo "<script>
    function uncheckAll(element) {
        var checkboxes = document.getElementsByName('character');
        checkboxes.forEach(function(checkbox) {
            if (checkbox !== element) {
                checkbox.checked = false;
            }
        });
    }
    </script>";
                        echo "<br><button class='uhastnik_tur' type='submit'>Учавствовать</button>";
                    } else {
                        echo "Создайте персонажа на этом сервере для участия.";
                    }
                    ?>
                <input type="hidden" name="cat" value='<? echo $cat_tur ?>'>
                <input type="hidden" name="id_user" value='<? echo $id_user ?>'>
                <input type="hidden" name="server" value='<? echo $server ?>'>

            </form>
        </div>
    </div>
    <?php
    } elseif ($cat_tur == '2 VS 2') {

        // Блок для категории 2v2
        ?>

    <style>
    button {
        margin: 20px auto;
    }


    .checkbox-custom {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        display: inline-block;
        position: relative;
        background-color: none;
        border: 1px solid white;
        border-radius: 100%;
        color: #888;
        padding: 12px;
        cursor: pointer;
        margin-right: 10px;
    }

    .checkbox-custom:checked::before {
        content: '\2714';
        display: block;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        font-size: 18px;
        color: #fff;
        background-color: #888;
        border-radius: 50%;
        width: 24px;
        height: 24px;
        text-align: center;
        line-height: 24px;
    }
    </style>
    <div id="uniqueModal" class="unique-modal">
        <div class="unique-modal-content">
            <form id="characterForm" method="post" action="verdan/add_uhastnik_tur_2.php">
                <p>Персонажи команды:</p><br>

                <?php

                    // Проверяем статус капитана пользователя в таблице "team"
                    $sql_team = "SELECT * FROM team WHERE id_user = '$id_user' AND rol = 'captain'";
                    $result_team = $connect->query($sql_team);

                    if ($result_team->num_rows > 0) {
                        // Получаем имя капитана и название команды из результата запроса
                        $captain_row = $result_team->fetch_assoc();
                        $captain_name = $captain_row['name'];
                        $team_name = $captain_row['name'];

                        // Выбираем всех участников группы с именем капитана
                        $sql_members = "SELECT t.id_user, c.id, c.nickname, u.login FROM team t 
                    JOIN characters c ON t.id_user = c.id_users
                    JOIN users u ON t.id_user = u.id
                    WHERE t.name = '$captain_name' and server ='$server'";
                        $result_members = $connect->query($sql_members);

                        if ($result_members->num_rows > 0) {
                            $id_users_check = array(); // Массив для проверки id_users
                
                            while ($row = $result_members->fetch_assoc()) {
                                // Получаем информацию о персонаже и пользователе
                                $member_id = $row['id_user'];
                                $character_id = $row['id'];
                                $character_nickname = $row['nickname'];
                                $user_login = $row['login'];

                                // Добавляем id_users в массив
                                $id_users_check[] = $member_id;
                            }

                            // Проверяем, сколько персонажей с одинаковыми id_users
                            $unique_id_users = array_unique($id_users_check);
                            $num_unique_id_users = count($unique_id_users);

                            if ($num_unique_id_users > 1) {
                                // Если есть несколько персонажей с одинаковыми id_users, выводим чекбоксы
                                echo "<form id='characterForm' method='post'>";
                                foreach ($unique_id_users as $id_user) {
                                    echo "<div>";
                                    foreach ($result_members as $row) {
                                        if ($row['id_user'] === $id_user) {
                                            $id = $row['id'];
                                            echo "<div>";
                                            echo "<input class='checkbox-custom' type='checkbox' name='selected_characters[$id_user][$id]' value='$id' id='char_$id'>";
                                            echo "<label for='char_$id'>" . $row['login'] . " - " . $row['nickname'] . "</label><br>";
                                            echo "</div>";
                                        }
                                    }

                                    echo "</div>";
                                }

                                // Кнопка по центру формы
                                echo "<div style='text-align: center;'>";
                                echo "<button  style='display: none'id='okButton' type='submit'>Окей</button>";
                                echo "</div>";
                                echo "<input type='hidden' name='cat' value='$cat_tur'>";
                                echo "<input type='hidden' name='server' value='$server'>";
                                echo "</form>";
                            } else {
                                // Если персонажей с одинаковыми id_users нет, просто выводим их
                                echo "Персонаж <br> $user_login - $character_nickname";
                            }
                        } else {
                            echo "В вашей группе на сервере $server нет других участников.";
                        }
                    } else {
                        // Пользователь не является капитаном, выводим сообщение
                        echo "Вы не являетесь капитаном и не можете принимать решения в участии.";
                    }

                    ?>

            </form>
        </div>
        <script>
        var checkboxes = document.querySelectorAll('input[type="checkbox"]');
        var maxAllowed = 2;

        checkboxes.forEach(function(checkbox) {
            checkbox.addEventListener('change', function() {
                var checkedCount = document.querySelectorAll('input[type="checkbox"]:checked').length;
                if (checkedCount > maxAllowed) {
                    this.checked = false;
                }

                var selectedLogins = [];
                checkboxes.forEach(function(cb) {
                    if (cb.checked) {
                        var login = cb.nextSibling.textContent.split(' - ')[0];
                        if (selectedLogins.includes(login)) {
                            cb.checked = false;
                        } else {
                            selectedLogins.push(login);
                        }
                    }
                });

                var okButton = document.getElementById('okButton');
                okButton.style.display = selectedLogins.length === maxAllowed ? 'block' : 'none';
            });
        });
        </script>
    </div>
    <?php
    } elseif ($cat_tur == '5 VS 5') {
        // Блок для категории 5v5
        ?>
    <style>
    .checkbox-custom {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        display: inline-block;
        position: relative;
        background-color: none;
        border: 1px solid white;
        border-radius: 100%;
        color: #888;
        padding: 12px;
        cursor: pointer;
        margin-right: 10px;
    }

    .checkbox-custom:checked::before {
        content: '\2714';
        display: block;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        font-size: 18px;
        color: #fff;
        background-color: #888;
        border-radius: 50%;
        width: 24px;
        height: 24px;
        text-align: center;
        line-height: 24px;
    }
    </style>
    <div id="uniqueModal" class="unique-modal">
        <div class="unique-modal-content">
            <form id="characterForm" method="post" action="verdan/add_uhastnik_tur_2.php">
                <p>Персонажи команды:</p><br>

                <?php

                    // Проверяем статус капитана пользователя в таблице "team"
                    $sql_team = "SELECT * FROM team WHERE id_user = '$id_user' AND rol = 'captain'";
                    $result_team = $connect->query($sql_team);

                    if ($result_team->num_rows > 0) {
                        // Получаем имя капитана и название команды из результата запроса
                        $captain_row = $result_team->fetch_assoc();
                        $captain_name = $captain_row['name'];
                        $team_name = $captain_row['name'];

                        // Выбираем всех участников группы с именем капитана
                        $sql_members = "SELECT t.id_user, c.id, c.nickname, u.login FROM team t 
                    JOIN characters c ON t.id_user = c.id_users
                    JOIN users u ON t.id_user = u.id
                    WHERE t.name = '$captain_name' and server ='$server'";
                        $result_members = $connect->query($sql_members);

                        if ($result_members->num_rows > 0) {
                            $id_users_check = array(); // Массив для проверки id_users
                
                            while ($row = $result_members->fetch_assoc()) {
                                // Получаем информацию о персонаже и пользователе
                                $member_id = $row['id_user'];
                                $character_id = $row['id'];
                                $character_nickname = $row['nickname'];
                                $user_login = $row['login'];

                                // Добавляем id_users в массив
                                $id_users_check[] = $member_id;
                            }

                            // Проверяем, сколько персонажей с одинаковыми id_users
                            $unique_id_users = array_unique($id_users_check);
                            $num_unique_id_users = count($unique_id_users);

                            if ($num_unique_id_users > 1) {
                                // Если есть несколько персонажей с одинаковыми id_users, выводим чекбоксы
                                echo "<form id='characterForm' method='post'>";
                                foreach ($unique_id_users as $id_user) {
                                    echo "<div>";
                                    foreach ($result_members as $row) {
                                        if ($row['id_user'] === $id_user) {
                                            $id = $row['id'];
                                            echo "<div>";
                                            echo "<input class='checkbox-custom' type='checkbox' name='selected_characters[$id_user][$id]' value='$id' id='char_$id' require>";
                                            echo "<label for='char_$id'>" . $row['login'] . " - " . $row['nickname'] . "</label><br>";
                                            echo "</div>";
                                        }
                                    }

                                    echo "</div>";
                                }

                                // Кнопка по центру формы
                                echo "<div style='text-align: center;'>";
                                echo "<button  style='display: none'id='okButton' type='submit'>Окей</button>";
                                echo "</div>";
                                echo "<input type='hidden' name='cat' value='$cat_tur'>";
                                echo "<input type='hidden' name='server' value='$server'>";
                                echo "</form>";
                            } else {
                                // Если персонажей с одинаковыми id_users нет, просто выводим их
                                echo "Персонажи<br> $user_login - $character_nickname";
                            }
                        } else {
                            echo "В вашей группе на сервере $server нет других участников.";
                        }
                    } else {
                        // Пользователь не является капитаном, выводим сообщение
                        echo "Вы не являетесь капитаном и не можете принимать решения в участии.";
                    }

                    ?>

            </form>
        </div>
        <script>
        var checkboxes = document.querySelectorAll('input[type="checkbox"]');
        var maxAllowed = 5;

        checkboxes.forEach(function(checkbox) {
            checkbox.addEventListener('change', function() {
                var checkedCount = document.querySelectorAll('input[type="checkbox"]:checked').length;
                if (checkedCount > maxAllowed) {
                    this.checked = false;
                }

                var selectedLogins = [];
                checkboxes.forEach(function(cb) {
                    if (cb.checked) {
                        var login = cb.nextSibling.textContent.split(' - ')[0];
                        if (selectedLogins.includes(login)) {
                            cb.checked = false;
                        } else {
                            selectedLogins.push(login);
                        }
                    }
                });

                var okButton = document.getElementById('okButton');
                okButton.style.display = selectedLogins.length === maxAllowed ? 'block' : 'none';
            });
        });
        </script>
    </div>
    <?php
    }
    ?>
    <script>
    var uniqueModal = document.getElementById('uniqueModal');

    function openUniqueModal() {
        uniqueModal.style.display = 'block';
    }

    function closeUniqueModal() {
        uniqueModal.style.display = 'none';
    }

    window.onclick = function(event) {
        if (event.target == uniqueModal) {
            uniqueModal.style.display = 'none';
        }
    }
    </script>
</body>

</html>