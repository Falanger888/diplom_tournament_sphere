<?php
session_start();
require_once "verdan/connect.php";

?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Турнирная сетка
    </title>
    <link rel="stylesheet" href="css/def_body.css">
</head>
<style>
    h1 {
        font-weight: 200;
        width: 590px;
        margin: 0 auto;
        color: white;
        background-color: rgba(217, 217, 217, 0.4);
        padding: 10px;
    }

    h2 {
        font-weight: 200;
        width: 380px;
        height: auto;
        margin: 0 auto;
        color: white;
        background-color: rgba(217, 217, 217, 0.4);
        padding: 10px;
        border-radius: 15px;
    }

    .member-1 {
        width: 320px;
        height: 75px;
        background-color: rgba(217, 217, 217, 0.4);
        border-radius: 37px;
        margin: 25px 50px;
        text-align: center;
        position: relative;
        line-height: 75px;
        color: white;
    }

    .member-1::after {
        content: "";
        position: absolute;
        top: 50%;
        right: -25px;
        width: 25px;
        height: 2px;
        background-color: #ffffff;
        transform: translate(0, 100%);
    }

    .main_flex {
        display: flex;
        width: 100%;
    }

    .main_flex_2 {
        display: flex;
        width: auto;
        margin-left: 375px;
    }

    .member-2 {
        width: 320px;
        height: 75px;
        background-color: rgba(217, 217, 217, 0.4);
        border-radius: 37px;
        margin: 70px 0px;
        text-align: center;
        position: relative;
        line-height: 75px;
        color: white;
    }

    .member-2::before {
        content: "";
        position: absolute;
        top: -105px;
        left: -25px;
        width: 2px;
        height: 101px;
        background-color: #ffffff;
        transform: translate(0, 100%);
    }
</style>



<body>
    <?php
    include "header.php";
    ?>
    <h1>Турнирная сетка
    </h1>
    <br><br><br><br>
    <div class='main_flex'>
        <div>
            <div class="member-1">
                <p>Участник 1</p>
            </div>
            <div class="member-1">
                <p>Участник 2</p>
            </div>
        </div>
        <div>
            <div class="line">
            </div>
            <div class="member-2">

                <p>Участник 2</p>
            </div>
        </div>
    </div>
    <div class='main_flex'>
        <div>
            <div class="member-1">
                <p>Участник 3</p>
            </div>
            <div class="member-1">
                <p>Участник 4</p>
            </div>
        </div>
        <div>
            <div class="line">
            </div>
            <div class="member-2">

                <p>Участник 2</p>
            </div>
        </div>
    </div>
    <div class='main_flex_2'>
        <div>
            <div class="member-1">
                <p>Участник 1</p>
            </div>
            <div class="member-1">
                <p>Участник 2</p>
            </div>
        </div>
        <div>
            <div class="line">
            </div>
            <div class="member-2">

                <p>Участник 2</p>
            </div>
        </div>
    </div>

    <br><br><br>
    <?php
    include "footer.php";
    ?>
</body>

</html>