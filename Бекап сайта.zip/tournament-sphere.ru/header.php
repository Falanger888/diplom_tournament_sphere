<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();
   for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
   k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(97443718, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/97443718" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<link rel="stylesheet" href="css/header.css">

<style>
.burger {
    display: none;
}
.exit-2 {
    margin-right: 60px;
    text-decoration: none;
    color: rgba(129, 48, 54, 1);
}

nav>ul>li>a:hover {
    background-color: rgba(217, 217, 217, 0.8);
    border-radius: 30px;
    padding: 10px;
    scale: 1.1;

}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {

  display: none;
  position: absolute;
  background-color: #f9f9f9;
  width: 100%; /* Adjust the width as needed */
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
  z-index: 1;
  opacity: 0;
  transition: opacity 0.3s ease, transform 0.3s ease, height 0.5s ease; /* Added transition for height and transform */
  transform-origin: top; /* Set the origin for the transform */
  transform: translateY(-100%); /* Initially set above the parent */
}

.dropdown-content a {
  color: rgba(129, 48, 54, 1);
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {
  background-color: #f1f1f1;
}

.dropdown:hover .dropdown-content {
  display: block;
  opacity: 1;
  transform: translateY(0);
  height: auto;
  animation: slide-down 0.5s forwards;
}
@keyframes slide-down {
        from {
            opacity: 0;
            transform: translateY(-50%);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }



.logo > a > .logo {
    filter: drop-shadow(2px 2px 0 gray);
    transition: filter 0.5s;
}
.logo>a>.logo:hover{
    filter: drop-shadow(
   5px 5px 10px gray );
   transition 0.5s;

}
.silka-1100{
    display:none;
    width:110px;
}
@media (max-width: 1100px) {
    
    

  
    .burger {
        display: flex;
    }

    nav {
        display: none;
        flex-direction: column;
        position: fixed;
        height: 400px;
        width: 280px;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        z-index: 50;
        overflow-y: auto;
        padding: 50px 40px;

        background-color: rgba(217, 217, 217, 0.8);
        text-align: left;

    }

    nav ul {
        flex-direction: column;
        row-gap: 45px;
    }


    .active {
        display: flex !important;
    }

    nav a {
        background-color: rgba(217, 217, 217, 0.7);
        padding: 10px;
        border-radius: 15px;
        font-size: 24px;
    }
    .dropdown{
        display:none;
    }
  .silka-1100{
    display:block;
}

}



.exit {
    filter: drop-shadow(0px 0px 0 gray);
    transition: filter 0.5s;
   
}
.exit:hover{
    filter: drop-shadow(
   5px 5px 10px gray );
   

}


    .preloader {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        /* Прозрачный белый фон */
        z-index: 9999;
        /* Значение z-index должно быть выше, чем у любого другого элемента на странице */
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .spinner img {
        width: 300px;
        height: 300px;
    }
.text_preloader{
        color: white;
    }

</style>
<header>
    <div class='burger'>
        <img src="img/update/burger.png" alt="burger">
    </div>
    <div class="logo">
        <a href="main.php"><img class="logo" src="img/Лого.png" alt="logo"></a>
    </div>
    <nav>
        <ul>
            <li><a class="silka" href="news.php">Новости</a></li>

            <li>



            <a class="silka silka-1100" href="turnir_cat.php">Турниры</a>
                <div class="dropdown">
                    <a class="silka" href="turnir_cat.php">Турниры</a>
                    <div class="dropdown-content">
                        <a href="#" onclick="postData('1 VS 1')">1 VS 1</a>
                        <a href="#" onclick="postData('2 VS 2')">2 VS 2</a>
                        <a href="#" onclick="postData('5 VS 5')">5 VS 5</a>
                    </div>
                </div>
            </li>
            <li><a class="silka" href="team.php">Команда</a></li>
            <li><a class="silka" href="search_users.php">Поиск игроков</a></li>
            <li><a class="silka" href="profile.php">Профиль</a></li>
            <li><a class="silka" href="suport.php">Поддержка</a></li>
        </ul>
    </nav>
    <div>

        <?php
    if (!isset($_SESSION['user'])) {
      echo '<a class="exit-2" class="silka" href="Authorization.php">Войти</a>';
    } else {
      ?>
        <a onclick="openModal2()" href="#"><img class="exit" src="img/выход.png" alt="exit"></a>

        <!-- Модальное окно -->
        <div id="modal2" class="modal">
            <div class="modal-content">
                <p class="text-modal">Хотите выйти из аккаунта?</p>
                <button onclick="logout()" class="modal-button">Выход</button>
                <button onclick="closeModal2()" class="modal-button">Отмена</button>
            </div>
        </div>

        <script src="js/config_exit.js"></script>
        <script>
        function openModal2() {
            document.getElementById("modal2").style.display = "block";
        }

        function closeModal2() {
            document.getElementById("modal2").style.display = "none";
        }

        function logout() {
            window.location.href = "verdan/logout.php"; // Замените на URL вашего скрипта выхода
        }

        // Обработчик события для закрытия модального окна при щелчке вне его области
        window.onclick = function(event) {
            var modal = document.getElementById("modal2");
            if (event.target == modal) {
                closeModal2();
            }
        }
        </script>
        <?php
    }
    ?>
        <script>
        document.querySelector('.burger').addEventListener('click', function(e) {
            e.stopPropagation();
            this.classList.toggle('active');
            document.querySelector('nav').classList.toggle('active');
        });

        document.addEventListener('click', function(e) {
            const nav = document.querySelector('nav');
            if (!nav.contains(e.target) && !document.querySelector('.burger').contains(e.target)) {
                nav.classList.remove('active');
                document.querySelector('.burger').classList.remove('active');
            }
        });
        
        
        function postData(value) {
    var form = document.createElement('form');
    form.method = 'post';
    form.action = 'turnir_server.php';

    var input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'cat_tur';
    input.value = value;

    form.appendChild(input);
    document.body.appendChild(form);
    form.submit();
}
        </script>
    </div>
</header>
<body>
   <div class="preloader">
        <div class="spinner">
            <img src="кот чавкает.gif" alt="Прелоадер">
            <p class='text_preloader'>Идет загрузка сайта.</p>
        </div>
    </div>
<script>
  document.addEventListener("DOMContentLoaded", function() {
    var preloader = document.querySelector('.preloader');
    // Задержка прелоадера на 5 секунд (5000 миллисекунд)
    setTimeout(function() {
      preloader.style.display = 'none';
    }, 1000);
  });
</script>
    
 