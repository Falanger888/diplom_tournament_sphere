<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Поиск команды</title>
    <link rel="stylesheet" href="css/def_body.css">

</head>
<style>
div,
h1 {
    color: white;

}



h1 {
    font-weight: 300;
    text-align: center;
    margin-top: auto;
    background-color: rgba(217, 217, 217, 0.4);
    width: 534px;
    margin: 0 auto;
    padding: 10px;
}

label {
    font-family: 'Montserrat Alternates', sans-serif;
    font-size: 32px;
    margin-top: 40px;
    font-weight: 200;
}

body>div>p {
    text-align: center;
    margin: 0 auto;
    align-items: center;
    width: 962px;
    font-size: 32px;
}

form {
    height: 350px;
    margin: 0 auto;
    width: 640px;
    background-color: rgba(217, 217, 217, 0.4);
    display: flex;
    flex-direction: column;
    align-items: center;

}

input {
    background-color: rgba(217, 217, 217, 0.4);
    color: white;
    width: 483px;
    margin-top: 50px;
    border: 0;
    border-radius: 11px;
    height: 59px;
    font-family: 'Montserrat Alternates', sans-serif;
    padding: 5px;
    font-size: 30px;

}

button {
    margin-top: 40px;
    border-radius: 5px;
    padding: 3px;
    font-weight: 300;
    height: 70px;
    width: 200px;
    border: 0;
    background-color: rgba(217, 217, 217, 0);
    color: white;
    font-size: 25px;
    transition: 0.5s;
    cursor: pointer;
    font-family: 'Montserrat Alternates', sans-serif;
}

button:hover {
    cursor: pointer;
    transition: 0.5s;
    background-color: rgba(217, 217, 217, 0.5);
}

.messange {
    all: unset;
    color: white;
    font-size: 24px;
    margin-top: 10px;
}

@media only screen and (max-width: 400px) {
        h1{
            width:300px;
            font-size:24px;
        }
        form{
            width:350px;
            height:350px;
        }
        input{
            width:300px;
        }
        label{
            font-size:20px;
        }
        body>div>p{
            width:300px;
            font-size:18px;
        }
    }
</style>

<body>
    <?php
    include "header.php";
    ?>
    <h1>Поиск команды</h1>
    <div>
        <br>
        <p>Введите существующие название команды, для того, чтобы отправить запрос на присоединение</p>
        <br>
        <form action="verdan/search_team.php" method="POST">
            <label for="">Введите название команды</label>
            <input type="text" name='team'>
            <p class="messange">
                <?php

                if (isset($_SESSION['message'])) {
                    echo $_SESSION['message'];
                    unset($_SESSION['message']); // Очищаем переменную сообщения
                }
                ?>
            </p>
            <button type="submit">Готово</button>
        </form>
    </div>
    <br><br><br>
    <?php
    include "footer.php";
    ?>
</body>

</html>