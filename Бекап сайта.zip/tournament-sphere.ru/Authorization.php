<?php
session_start();

?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация</title>
    <style>
        * {
            margin: 0;
            padding: 0;
        }

        @font-face {
            font-family: 'Montserrat Alternates';
            src: url('fonts/MontserratAlternates-Regular.ttf') format('truetype');
            font-weight: normal;
            font-style: normal;
        }

        body {
            background-image: url('img/фон_регистрация.png');
            font-family: 'Montserrat Alternates', sans-serif;
            font-weight: 700;
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center center;
            /* Позиционирует изображение по центру экрана */
        }

        .fon {
            margin-left: 10%;
            margin-top: 150px;
            width: 732px;
            height: 865px;
            background-color: rgba(190, 194, 200, 0.5);
            display: flex;
            flex-direction: column;
            align-items: center;

        }

        form {
            width: 80%;
            align-items: center;
            margin-top: 20px;
            display: block;
            text-align: left;
            flex-direction: column;
            text-align: left;
        }

        .fon>img {
            width: 332px;
            margin-top: 30px;
            padding-bottom: 40px;
        }

        input {
            color: white;
            background-color: rgba(217, 217, 217, 0.9);
            margin-bottom: 20px;
            margin-right: 100px;
            border: 0;
            border-radius: 21px;
            padding: 5px;
            font-family: 'Montserrat Alternates', sans-serif;
            width: 569px;
            height: 77px;
            font-size: 40px;
        }

        label {
            color: rgba(255, 255, 255, 1);
            font-size: 40px;
            margin: 10px;
            font-weight: 100;
            text-align: left;
        }

        button {
            border-radius: 18px;
            margin-left: 27%;
            border: 0;
            font-family: 'Montserrat Alternates', sans-serif;
            font-size: 40px;
            margin-top: 70px;
            width: 250px;
            height: 100px;
            color: white;
            background-color: rgba(217, 217, 217, 0.4);
            transition: 0.5s;
        }

        button:hover {
            transition: 0.5s;
            cursor: pointer;
            background-color: rgba(190, 194, 200, 0.7);
        }

        p {
            font-weight: 300;
            color: white;
            margin-top: 70px;
            font-size: 30px;
        }

        a {
            text-decoration: none;
            color: rgba(129, 48, 54, 1);
            transition: 0.5s;
        }

        a:hover {
            transition: 0.5s;
            color: rgba(156, 83, 88, 1);
        }
        .uspeh{
           text-align: center;
           margin-top: 20px;
        }
        .fon>a>img{
            width: 370px;
            margin-top: 35px;

        }
        
@media (max-width: 600px){
  .fon{
      margin-top:30px;
      width:300px;
      height:550px;
  }
  .fon>a>img{
            width: 170px;
            margin-top: 35px;

        }
        input{
            width:230px;
            height:30px;
            font-size:18px;
            margin-right:0px;
            border-radius:10px;
        }
        button{
            margin-left:27%;
            margin-top:30px;
            font-size:24px;
            width:100px;
            height:50px;
            border-radius:10px;
        }
        p{
            margin-top:30px;
        font-size:18px;
        margin-left:20%;
        }
        label{
            font-size:24px;
        }
}
    </style>
</head>

<body>
    <div class="fon"> <a href="main.php"><img src="img/Лого.png" alt="logo"></a>
        <form action="verdan/signin.php" class="login-form" method="POST">
            <label for="login">Логин</label>
            <input name="login" type="text" id="login">
            <label for="password">Пароль</label>
            <input name="password" type="password" id="password">
            <button>Войти</button>
            <p class='uspeh'>
                <?php
                if (isset($_SESSION['message'])) {

                    echo $_SESSION['message'];

                    unset($_SESSION['message']);
                }
                ?>
            </p>
        </form>
        <p>Нет аккаунта? <a href="Register.php">Зарегистрируйся!</a></p>
    </div>
</body>

</html>