<?php
session_start();
require_once "verdan/connect.php";

$cat_tur = $_POST['cat_tur'];


$query = "SELECT * FROM tournament";
$result = $connect->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Выбор сервера
        <? echo $cat_tur ?>
    </title>
    <link rel="stylesheet" href="css/def_body.css">
</head>
<style>
h1 {
    display: inline-block;
    color: white;
    background-color: rgba(217, 217, 217, 0.4);
    padding: 10px;
    font-size: 48px;
}

body {
    width: 100%;
}

.main-flex {
    width: 80%;
    margin: 0 auto;
    color: white;
    font-weight: 200;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-items: flex-start;
}

.main-flex {}

.cat {
    width: 30%;
    margin-bottom: 20px;
}

.cat {
    background-color: rgba(217, 217, 217, 0.4);
    width: 425px;
    height: 425px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.table-cat {

    border-radius: 5px;
    font-weight: 300;
    height: 70px;
    width: 200px;
    border: 0;
    background-color: rgba(217, 217, 217, 0.4);
    color: white;
    font-size: 25px;
    transition: 0.5s;
    cursor: pointer;
    font-family: 'Montserrat Alternates', sans-serif;
}

button:hover {
    transition: 0.5s;
    background-color: rgba(217, 217, 217, 0.8);
}

.img {

    width: 350px;
    height: 350px;
    background: rgba(217, 217, 217, 0.8);
    display: flex;
    justify-content: center;
    align-items: end;


}

button {
    padding: 3px;
    transition: 0.5s;
    height: 50px;
    background: none;
    border: none;
    width: auto;
    margin: 5px;
    font-size: 32px;
    color: white;
    border-radius: 5px;
    cursor: pointer;
}

.main-buuton-bottom {
    margin-top: 150px;
    display: flex;
    justify-content: space-around;
    align-items: center;
    flex-direction: column;

}

.container-zag {
    text-align: center;
}


.img_1,
.img_2 {
    background-size: contain;
    background-position: center;
    background-repeat: no-repeat;
}



@media only screen and (max-width: 1700px) {

    .cat {
        width: 325px;
        height: 325px;

    }

    .img {

        width: 280px;
        height: 280px;


    }

    .img_1,
    .img_2,
    .img_3 {

        width: 270px;
        height: 270px;
        display: flex;
        justify-content: center;
        align-items: end;


    }


    .main-buuton-bottom {
        margin-top: 50px;


    }


}

@media only screen and (max-width: 1440px) {
    .cat {
        width: 225px;
        height: 225px;

    }

    .img_1,
    .img_2,
    .img_3 {

        width: 175px;
        height: 175px;
        display: flex;
        justify-content: center;
        align-items: end;


    }

    .img {

        width: 190px;
        height: 190px;


    }

    .main-buuton-bottom {
        margin-top: 50px;


    }
}

.block_live {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-column-gap: 20px;
}
.cat_1>.cat>.img {
    background-image: url("img/server/луций.jpg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
}

.cat_2>.cat>.img {
    background-image: url("img/server/корвусы.jpeg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
}

.cat_3>.cat>.img {
    background-image: url("img/server/фанем.jpg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
}

.cat_4>.cat>.img {
    background-image: url("img/server/шаеда.jpg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
}

.cat_5>.cat>.img {
    background-image: url("img/server/ифнир.jpg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
}

.cat_6>.cat>.img {
    background-image: url("img/server/ксанатос.jpg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
}

.cat_7>.cat>.img {
    background-image: url("img/server/Тарон.jpg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
}

.cat_8>.cat>.img {
    background-image: url("img/server/рейвен.jpg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
}

.cat_9>.cat>.img {
    background-image: url("img/server/нагашар.jpg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
}


@media only screen and (max-width: 400px) {

        h1 {
            font-size:24px;
        }

        .block_live{
            display:block;
        }
    }
</style>



<body>
    <?php
    include "header.php";
    ?>
    <div class="container-zag">
        <h1>Выбор серверов
            <? echo $cat_tur ?>
        </h1>
    </div>

    <br><br>
    <div class="main-flex">

        <div>
            <h1>Лайвы</h1>
            <br>
            <div class='block_live'>
                <div class='cat_1'>
                    <div class="cat">
                        <div class="img">
                            <form action="server_table.php" method="POST">
                                <input type="text" name="cat_tur" hidden value="<? echo $cat_tur ?>">
                                <input type="text" name="server" hidden value="Луций">
                                <button type='submith'>Луций</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class='cat_2'>
                    <div class="cat">
                        <div class="img">
                            <form action="server_table.php" method="POST">
                                <input type="text" name="cat_tur" hidden value="<? echo $cat_tur ?>">
                                <input type="text" name="server" hidden value="Корвус">
                                <button type='submith'>Корвус</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class='cat_3'>
                    <div class="cat">
                        <div class="img">
                            <form action="server_table.php" method="POST">
                                <input type="text" name="cat_tur" hidden value="<? echo $cat_tur ?>">
                                <input type="text" name="server" hidden value="Фанем">
                                <button type='submith'>Фанем</button>
                            </form>

                        </div>
                    </div>
                </div>
                <div class='cat_4'>
                    <div class="cat">
                        <div class="img">
                            <form action="server_table.php" method="POST">
                                <input type="text" name="cat_tur" hidden value="<? echo $cat_tur ?>">
                                <input type="text" name="server" hidden value="Шаеда">
                                <button type='submith'>Шаеда</button>
                            </form>

                        </div>
                    </div>
                </div>
                <div class='cat_6'>
                    <div class="cat">
                        <div class="img">
                            <form action="server_table.php" method="POST">
                                <input type="text" name="cat_tur" hidden value="<? echo $cat_tur ?>">
                                <input type="text" name="server" hidden value="Ксанатос">
                                <button type='submith'>Ксанатос</button>
                            </form>

                        </div>
                    </div>
                </div>
                <div class='cat_7'>
                <div class="cat">
                    <div class="img">
                        <form action="server_table.php" method="POST">
                            <input type="text" name="cat_tur" hidden value="<? echo $cat_tur ?>">
                            <input type="text" name="server" hidden value="Тарон">
                            <button type='submith'>Тарон</button>
                        </form>

                    </div>
                </div>
            </div>
            </div>

        </div>
        <div>
            <h1>Клетка</h1>
            
                <div class='cat_5'>
                    <div class="cat">
                        <div class="img">
                            <form action="server_table.php" method="POST">
                                <input type="text" name="cat_tur" hidden value="<? echo $cat_tur ?>">
                                <input type="text" name="server" hidden value="Ифнир">
                                <button type='submith'>Ифнир</button>
                            </form>

                        </div>
                    </div>
                </div>
            
            <div class='cat_8'>
                <div class="cat">
                    <div class="img">
                        <form action="server_table.php" method="POST">
                            <input type="text" name="cat_tur" hidden value="<? echo $cat_tur ?>">
                            <input type="text" name="server" hidden value="Рейвен">
                            <button type='submith'>Рейвен</button>
                        </form>

                    </div>
                </div>
            </div>
            <div class='cat_9'>
                <div class="cat">
                    <div class="img">
                        <form action="server_table.php" method="POST">
                            <input type="text" name="cat_tur" hidden value="<? echo $cat_tur ?>">
                            <input type="text" name="server" hidden value="Нагашар">
                            <button type='submith'>Нагашар</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>





    </div>

    <br><br><br>
    <?php
    include "footer.php";
    ?>
</body>

</html>