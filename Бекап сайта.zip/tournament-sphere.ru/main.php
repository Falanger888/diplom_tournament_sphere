<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Главная Tournament sphere</title>

    <link rel="stylesheet" href="css/def_body.css">


    <style>
    .text-1 {
        font-weight: 100;
        color: white;
        background-color: rgba(217, 217, 217, 0.4);
        padding: 20px;
        width: 800px;
        font-size: 40px;


    }

    .text-2 {
        margin-bottom: 30px;
        height: 70px;
        line-height: 70px;
        font-weight: 100;
        color: white;
        background-color: rgba(217, 217, 217, 0.4);
        padding: 5px;
        width: 970px;
        font-size: 40px;

    }


    .main_flex_tur {
        display: flex;
        justify-content: space-around;
    }


    @media only screen and (max-width: 1700px) {
        body {
            font-size: 25px;
        }

        .text-1 {
            font-weight: 100;
            color: white;
            background-color: rgba(217, 217, 217, 0.4);
            padding: 20px;
            width: 700px;
            font-size: 32px;

        }

        .text-2 {
            margin-top: 30px;
            height: 70px;
            line-height: 70px;
            font-weight: 100;
            color: white;
            background-color: rgba(217, 217, 217, 0.4);
            padding: 5px;
            width: 780px;
            font-size: 32px;

        }
    }


    @media only screen and (max-width: 1440px) {
        body {
            font-size: 25px;
        }

        .text-1 {
            font-weight: 100;
            color: white;
            background-color: rgba(217, 217, 217, 0.4);
            padding: 20px;
            width: 570px;
            font-size: 28px;

        }

        .text-2 {
            margin-top: 30px;
            height: 70px;
            line-height: 70px;
            font-weight: 100;
            color: white;
            background-color: rgba(217, 217, 217, 0.4);
            padding: 5px;
            width: 680px;
            font-size: 28px;

        }
    }




    @media only screen and (max-width: 1200px) {
        body {
            font-size: 20px;
        }

        .text-1 {
            font-weight: 100;
            color: white;
            background-color: rgba(217, 217, 217, 0.4);
            padding: 20px;
            width: 480px;
            font-size: 24px;

        }

        .text-2 {
            height: 70px;
            line-height: 70px;
            font-weight: 100;
            color: white;
            background-color: rgba(217, 217, 217, 0.4);
            padding: 5px;
            width: 590px;
            font-size: 24px;

        }
    }
    
    @media (max-width: 1100px) {

        
        .text-1{
            height: 60px;
            font-weight: 100;
            line-height:20px;
            color: white;
            background-color: rgba(217, 217, 217, 0.4);
            padding: 5px;
            width: 300px;
            font-size: 18px;
            margin:0 auto;
            
        }
        .text-2 {
            
            height: 50px;
            font-weight: 100;
            line-height:20px;
            color: white;
            background-color: rgba(217, 217, 217, 0.4);
            padding: 5px;
            width: 300px;
            font-size: 18px;
            margin:0 auto;

        }
        
        .main_flex_tur{
            display:block;
        }
}

.center {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    gap: 10px; 
}
    </style>

</head>

<body>
    <?php
    include "header.php";
    ?>
    <br>
    <div class='center'>
         <div class="text-2">
            <p>Добро пожаловать в TOURNAMENT SPHERE!</p>
        </div>
        <div class="text-1">
            <p>Официальное сообщество</p>
            <p>по организации турниров ArcheAge</p>
        </div>
        <br>
       

    </div>





    <?php
    include "footer.php";
    ?>
</body>

</html>