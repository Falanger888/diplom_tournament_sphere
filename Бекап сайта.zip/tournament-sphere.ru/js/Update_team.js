

// Режим редактирования

let isEditMode = false; // Флаг для определения режима редактирования
let originalEmail = ''; // Переменная для хранения оригинального значения email
let originalLogin = ''; // Переменная для хранения оригинального значения login

function toggleEditMode() {
    isEditMode = !isEditMode; // Изменяем флаг при каждом вызове функции
    const profileDetails = document.querySelector('.profile-details');
    const loginElement = document.querySelector('.team-name');
    const saveButton = document.querySelector('.save-button');

    if (isEditMode) {
        // Включаем режим редактирования
        originalLogin = loginElement.innerText; // Сохраняем оригинальное значение login

        loginElement.innerHTML = `<input type="text" class="login-input" value="${originalLogin}">`;
        saveButton.style.display = 'block';
    } else {
        // Выключаем режим редактирования
        const loginInput = document.querySelector('.login-input');

        loginElement.innerHTML = originalLogin; // Восстанавливаем оригинальное значение login
        saveButton.style.display = 'none';
    }
}

function saveProfileChanges() {
    const loginInput = document.querySelector('.login-input');

    // Создание формы
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = 'verdan/update_team.php';

    // Создание полей формы
    const loginField = document.createElement('input');
    loginField.type = 'hidden';
    loginField.name = 'login';
    loginField.value = loginInput.value;
    form.appendChild(loginField);


    const teamField = document.createElement('input');
    teamField.type = 'hidden';
    teamField.name = 'team';
    teamField.value = team;
    form.appendChild(teamField);

    // Добавление формы на страницу и отправка
    document.body.appendChild(form);
    form.submit();

    toggleEditMode(); // Выключить режим редактирования
}

window.onload = function () {

};