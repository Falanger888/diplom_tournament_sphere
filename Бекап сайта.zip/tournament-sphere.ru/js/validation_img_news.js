        // Валидация картинки
        var fileInput = document.getElementById('fileInput');
        var fileInputLabel = document.getElementById('fileInputLabel');
        var selectedFileMessage = document.getElementById('selectedFileMessage');
        var fileName = document.getElementById('fileName');

        fileInput.addEventListener('change', function () {
            var file = fileInput.files[0];
            var fileType = file ? file.type : null;

            // Проверяем, является ли файл изображением
            if (file && !fileType.startsWith('image/')) {
                // Если файл не является изображением, сбрасываем выбор файла
                fileInput.value = '';
                selectedFileMessage.style.display = 'none';
                fileName.textContent = '';
                fileInputLabel.textContent = 'Выберите файл (изображение)';
                alert('Пожалуйста, выберите файл в формате изображения.');
            } else {
                selectedFileMessage.style.display = 'block';
                fileName.textContent = file ? file.name : '';
            }
        });

        function openModal1() {
            document.getElementById("modal1").style.display = "block";
        }

        // Закрытие модального окна
        function closeModal1() {
            document.getElementById("modal1").style.display = "none";
        }
        // Обработчик события для закрытия модального окна при щелчке вне его области
        window.onclick = function (event) {
            var modal = document.getElementById("modal1");
            if (event.target == modal) {
                closeModal1();
            }
        }