function openModal2() {
  document.getElementById("modal2").style.display = "block";
}

function closeModal2() {
  document.getElementById("modal2").style.display = "none";
}

function logout() {
  window.location.href = "verdan/logout.php"; // Замените на URL вашего скрипта выхода
}

// Обработчик события для закрытия модального окна при щелчке вне его области
window.onclick = function (event) {
  var modal = document.getElementById("modal2");
  if (event.target !== modal && !modal.contains(event.target)) {
    closeModal2();
  }
};