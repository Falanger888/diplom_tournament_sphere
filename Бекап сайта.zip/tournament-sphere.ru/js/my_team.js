// Аватарка

const avatarContainer = document.querySelector('.avatar-container');
const avatarOverlay = document.querySelector('.avatar-overlay');
const avatarInput = document.querySelector('#avatar');
const avatarForm = document.querySelector('#avatarForm');

avatarContainer.addEventListener('click', () => {
    if ('<?php echo $rol ?>' === 'captain') {
        avatarInput.click();
    }
});

avatarInput.addEventListener('change', () => {
    if ('<?php echo $rol ?>' !== 'captain') {
        return; // Do not proceed if not a captain
    }

    const file = avatarInput.files[0];

    const formData = new FormData(avatarForm);
    formData.append('avatar', file);

    fetch('verdan/update/update_team_img.php', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.reload(); // Перезагрузка страницы
            } else {
                alert(data.error);
            }
        })
        .catch(error => {
            console.error(error);
            alert('Произошла ошибка при загрузке файла.');
        });
});



