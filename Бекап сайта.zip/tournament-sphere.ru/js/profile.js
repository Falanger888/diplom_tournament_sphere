function updateSelects(serverId) {
    var serverSelect = document.getElementById("server-select");
    var classSelect = document.getElementById("class-select");
    var nicknameSelect = document.getElementById("nickname-select");

    // Получаем выбранный сервер
    var selectedServerOption = serverSelect.options[serverSelect.selectedIndex];
    var selectedServerValue = selectedServerOption.value;

    // Устанавливаем значение выбранного сервера в селектах "class-select" и "nickname-select"
    classSelect.value = selectedServerValue;
    nicknameSelect.value = selectedServerValue;

    // Обновляем значения в полях ввода
    updateInputs();
}

function updateInputs() {
    var serverSelect = document.getElementById("server-select");
    var nicknameSelect = document.getElementById("nickname-select");
    var serverInput = document.getElementById("server-delete");
    var nicknameInput = document.getElementById("nick-delete");

    // Получаем выбранный сервер
    var selectedServerOption = serverSelect.options[serverSelect.selectedIndex];
    var selectedServerText = selectedServerOption.text;

    // Получаем выбранный никнейм
    var selectedNicknameOption = nicknameSelect.options[nicknameSelect.selectedIndex];
    var selectedNicknameText = selectedNicknameOption.text;

    // Устанавливаем значения в поля ввода
    serverInput.value = selectedServerText;
    nicknameInput.value = selectedNicknameText;
}

// Функция передающее значение при загрузке страницы
window.addEventListener('load', function () {
    var nicknameOptions = document.getElementById("nickname-select").options;
    var firstOptionText = nicknameOptions[0].innerHTML;
    document.getElementById("nick-delete").value = firstOptionText;
    var serverOptions = document.getElementById("server-select").options;
    var twoOptionText = serverOptions[0].innerHTML;
    document.getElementById("server-delete").value = twoOptionText;
});



// Валидация ника
var nickInput = document.getElementById('nick_new_pers');
var nickError = document.getElementById('nickError');
var lettersRegex = /^[A-Za-zА-Яа-я]+$/;

nickInput.addEventListener('input', function () {
    var nickValue = nickInput.value;
    if (nickValue.length < 3 || !lettersRegex.test(nickValue)) {
        nickError.textContent = 'Никнейм должен состоять из 3 букв';
    } else {
        nickError.textContent = '';
    }
});

// Проверка при отправке формы
document.getElementById("new_personag").addEventListener("submit", function (event) {
    var nickValue = nickInput.value;
    if (nickValue.length < 3 || !lettersRegex.test(nickValue)) {
        nickError.textContent = 'Никнейм должен состоять из 3 букв';
        event.preventDefault(); // Предотвращение отправки формы
        return;
    }
});



// Дальше норм модалка

function openCharacterModal() {
    document.getElementById("character-modal1").style.display = "block";
}

function closeCharacterModal() {
    document.getElementById("character-modal1").style.display = "none";
}

document.addEventListener("click", function (event) {
    var modal = document.getElementById("character-modal1");
    // Проверяем, был ли совершен щелчок вне модального окна
    if (event.target == modal) {
        closeCharacterModal();
    }
});



// Режим редактирования

let isEditMode = false; // Флаг для определения режима редактирования
let originalEmail = ''; // Переменная для хранения оригинального значения email
let originalLogin = ''; // Переменная для хранения оригинального значения login

function toggleEditMode() {
    isEditMode = !isEditMode; // Изменяем флаг при каждом вызове функции
    const profileDetails = document.querySelector('.profile-details');
    const loginElement = document.querySelector('.login-2');
    const saveButton = document.querySelector('.save-button');

    if (isEditMode) {
        // Включаем режим редактирования
        originalLogin = loginElement.innerText; // Сохраняем оригинальное значение login

        loginElement.innerHTML = `<input type="text" class="login-input" value="${originalLogin}">`;
        saveButton.style.display = 'block';
    } else {
        // Выключаем режим редактирования
        const loginInput = document.querySelector('.login-input');

        loginElement.innerHTML = originalLogin; // Восстанавливаем оригинальное значение login
        saveButton.style.display = 'none';
    }
}

function saveProfileChanges() {
    const loginInput = document.querySelector('.login-input');

    // Создание формы
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = 'verdan/update/update_login.php';

    // Создание полей формы
    const loginField = document.createElement('input');
    loginField.type = 'hidden';
    loginField.name = 'login';
    loginField.value = loginInput.value;
    form.appendChild(loginField);

    // Добавление формы на страницу и отправка
    document.body.appendChild(form);
    form.submit();

    toggleEditMode(); // Выключить режим редактирования
}

window.onload = function () {

};



// Аватарка

const avatarContainer = document.querySelector('.avatar-container');
const avatarOverlay = document.querySelector('.avatar-overlay');
const avatarInput = document.querySelector('#avatar');
const avatarForm = document.querySelector('#avatarForm');

avatarContainer.addEventListener('click', () => {
    avatarInput.click();
});

avatarInput.addEventListener('change', () => {
    const file = avatarInput.files[0];

    const formData = new FormData(avatarForm);
    formData.append('avatar', file);

    fetch('verdan/update/update_img.php', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                window.location.reload(); // Перезагрузка страницы
            } else {
                alert(data.error);
            }
        })
        .catch(error => {
            console.error(error);
            alert('Произошла ошибка при загрузке файла.');
        });
});