function updateSelects(serverId) {
    var serverSelect = document.getElementById("server-select");
    var classSelect = document.getElementById("class-select");
    var nicknameSelect = document.getElementById("nickname-select");

    // Получаем выбранный сервер
    var selectedServerOption = serverSelect.options[serverSelect.selectedIndex];
    var selectedServerValue = selectedServerOption.value;

    // Устанавливаем значение выбранного сервера в селектах "class-select" и "nickname-select"
    classSelect.value = selectedServerValue;
    nicknameSelect.value = selectedServerValue;

    // Обновляем значения в полях ввода
    updateInputs();
}

function updateInputs() {
    var serverSelect = document.getElementById("server-select");
    var nicknameSelect = document.getElementById("nickname-select");
    var serverInput = document.getElementById("server-delete");
    var nicknameInput = document.getElementById("nick-delete");

    // Получаем выбранный сервер
    var selectedServerOption = serverSelect.options[serverSelect.selectedIndex];
    var selectedServerText = selectedServerOption.text;

    // Получаем выбранный никнейм
    var selectedNicknameOption = nicknameSelect.options[nicknameSelect.selectedIndex];
    var selectedNicknameText = selectedNicknameOption.text;

    // Устанавливаем значения в поля ввода
    serverInput.value = selectedServerText;
    nicknameInput.value = selectedNicknameText;
}