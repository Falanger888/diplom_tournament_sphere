// Валидация картинки
        var fileInput = document.getElementById('fileInput');
        var fileInputLabel = document.getElementById('fileInputLabel');
        var selectedFileMessage = document.getElementById('selectedFileMessage');
        var fileName = document.getElementById('fileName');

        fileInput.addEventListener('change', function () {
            var file = fileInput.files[0];
            var fileType = file ? file.type : null;

            // Проверяем, является ли файл изображением
            if (file && !fileType.startsWith('image/')) {
                // Если файл не является изображением, сбрасываем выбор файла
                fileInput.value = '';
                selectedFileMessage.style.display = 'none';
                fileName.textContent = '';
                fileInputLabel.textContent = 'Выберите файл (изображение)';
                alert('Пожалуйста, выберите файл в формате изображения.');
            } else {
                selectedFileMessage.style.display = 'block';
                fileName.textContent = file ? file.name : '';
            }
        });

        // Валидация логина
        var loginInput = document.getElementById('login');
        var loginError = document.getElementById('login-error');
        var lettersRegex = /^[A-Za-zА-Яа-я]+$/;

        loginInput.addEventListener('input', function () {
            var loginValue = loginInput.value;
            if (loginValue.length < 3 || !lettersRegex.test(loginValue)) {
                loginError.textContent = 'Логин должен состоять из 3 букв';
            } else {
                loginError.textContent = '';
            }
        });

        // Валидация почты
        var emailInput = document.getElementById('email');
        var errorMsg = document.getElementById('error-msg');
        var pattern = /^[a-zA-Z0-9._-]+@(mail|gmail|yandex)\.(com|ru)$/;

        emailInput.addEventListener('input', function () {
            var email = emailInput.value;
            if (!pattern.test(email)) {
                errorMsg.style.display = 'block';
            } else {
                errorMsg.style.display = 'none';
            }
        });

        // Валидация никнейма
        var nickInput = document.getElementById('nickName');
        var nickError = document.getElementById('nickError');

        nickInput.addEventListener('input', function () {
            var nickValue = nickInput.value;
            if (nickValue.length < 3 || !lettersRegex.test(nickValue)) {
                nickError.textContent = 'Никнейм должен состоять из 3 букв';
            } else {
                nickError.textContent = '';
            }
        });

        // Валидация пароля
        var passwordInput = document.getElementById('password');
        var passwordError = document.getElementById('passwordError');
        var passwordRegex = /^(?=.*\d)(?=.*[a-zа-я])(?=.*[A-ZА-Я])[0-9a-zA-Zа-яА-Я]{8,}$/;

        passwordInput.addEventListener('input', function () {
            var passwordValue = passwordInput.value;
            if (!passwordRegex.test(passwordValue)) {
                passwordError.textContent = 'Пароль должен содержать как минимум 8 символов, включая как минимум одну цифру, одну строчную и одну заглавную букву.';
            } else {
                passwordError.textContent = '';
            }
        });

        // Валидация подтверждения
        var confirmPasswordInput = document.getElementById('confirmPassword');
        var confirmPasswordError = document.getElementById('confirmPasswordError');

        confirmPasswordInput.addEventListener('input', function () {
            var passwordValue = passwordInput.value;
            var confirmPasswordValue = confirmPasswordInput.value;
            if (passwordValue !== confirmPasswordValue) {
                confirmPasswordError.textContent = 'Пароли не совпадают.';
            } else {
                confirmPasswordError.textContent = '';
            }
        });

        // Проверка при отправке формы
        document.getElementById("registration-form").addEventListener("submit", function (event) {
            var loginValue = loginInput.value;
            var email = emailInput.value;
            var nickValue = nickInput.value;
            var passwordValue = passwordInput.value;
            var confirmPasswordValue = confirmPasswordInput.value;

            if (loginValue.length < 3 || !lettersRegex.test(loginValue)) {
                loginError.textContent = 'Логин должен состоять из 3 букв';
                event.preventDefault();
                return;
            }

            if (!pattern.test(email)) {
                errorMsg.style.display = 'block';
                event.preventDefault();
                return;
            }

            if (nickValue.length < 3 || !lettersRegex.test(nickValue)) {
                nickError.textContent = 'Никнейм должен состоять из 3 букв';
                event.preventDefault();
                return;
            }

            if (!passwordRegex.test(passwordValue)) {
                passwordError.textContent = 'Пароль должен содержать как минимум 8 символов, включая как минимум одну цифру, одну строчную и одну заглавную букву.';
                event.preventDefault();
                return;
            }

            if (passwordValue !== confirmPasswordValue) {
                confirmPasswordError.textContent = 'Пароли не совпадают.';
                event.preventDefault();
                return;
            }
        });