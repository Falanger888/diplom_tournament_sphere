<?php
session_start();
require_once "verdan/connect.php";
$query = "SELECT * FROM tournament";
$result = $connect->query($query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Текущие турниры</title>
    <link rel="stylesheet" href="css/def_body.css">
</head>
<style>
    h1 {
        width: 290px;
        margin: 0 auto;
        color: white;
        background-color: rgba(217, 217, 217, 0.4);
        padding: 10px;
    }

    table {
        margin: 0 auto;
        color: white;
        font-weight: 200;
        width: 90%;
        border-collapse: collapse;
        border: 1px solid white;
    }


    th,
    td {
        padding: 8px;
        text-align: left;
        border: 0.5px solid white;
    }

    th {
        border: 0.5px solid white;
    }

    .scrollable-container {
        max-height: 450px;
        overflow: auto;
    }

    .scrollable-container::-webkit-scrollbar {
        width: 0;
    }

    @media only screen and (max-width: 1600px) {

        h1 {
            width: 240px;


        }

        .scrollable-container {
            max-height: 350px;

        }
    }

    @media only screen and (max-width: 1200px) {

        h1 {
            width: 200px;


        }

        .scrollable-container {
            max-height: 250px;

        }
    }
    
    @media only screen and (max-width: 400px) {

        h1 {
            width: 200px;


        }

        .scrollable-container {
            max-height: 250px;
            width:350px;
            font-size:12px;
            margin-left:5px;

        }
        td{
            padding:4px;
        }
    }
</style>


<body>
    <?php
    include "header.php";
    ?>
    <h1>Турниры</h1>
    <br><br>
    <div class="scrollable-container">
        <table>
            <tr>
                <th>№</th>
                <th>Категория</th>
                <th>Название</th>
                <th>Сервер</th>
                <th>Призовой</th>
                <th>Статус</th>
            </tr>
            <?php
            // Вывод данных из таблицы
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['cat'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['server'] . "</td>";
                echo "<td>" . $row['priz'] . "</td>";
                echo "<td>" . $row['status'] . "</td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
    <br>
    <?php
    include "footer.php";
    ?>
</body>

</html>