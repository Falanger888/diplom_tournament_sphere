<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: Authorization.php");
    exit; 
}
$id_user = $_SESSION['user']['id'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ожидание</title>
    <link rel="stylesheet" href="css/def_body.css">
</head>
<style>
h1 {
    color: white;
    text-align: left;
    background-color: rgba(217, 217, 217, 0.4);
    width: 752px;
    margin: 0 auto;
    font-weight: 200;
    font-size: 32px;
    padding: 30px 10px;
}

.forma_zaprosa {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 100px;
}

button {
    margin-top: 25px;
    border-radius: 5px;
    padding: 3px;
    font-weight: 300;
    height: 70px;
    width: 450px;
    border: 0;
    background-color: rgba(217, 217, 217, 0);
    color: white;
    font-size: 40px;
    transition: 0.5s;
    cursor: pointer;
    font-family: 'Montserrat Alternates', sans-serif;
    margin-left: 10px;
}

button:hover {
    background-color: rgba(217, 217, 217, 0.4);
}
</style>

<body>
    <?php
    include "header.php";
    ?>
    <br><br><br><br><br><br><br>
    <h1>Вы отправили запрос,
        дождитесь ответа от лидера команды
        в уведомлениях профиля</h1>
    <form class="forma_zaprosa" action="verdan/delete_zapros.php">
        <button>Отменить запрос</button>
    </form>

    <?php
    include "footer.php";
    ?>
</body>

</html>