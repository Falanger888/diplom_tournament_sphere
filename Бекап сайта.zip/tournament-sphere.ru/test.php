<?php
require_once 'verdan/connect.php';

?>


<!doctype html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Турниры</title>
    <link rel='stylesheet' href='css/table.css'>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: sans-serif;
            list-style: none;
            text-decoration: none;
        }

        .container {
            width: 100%;
            height: 110vh;
            background-image: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8));
            background-position: center;
            background-size: cover;
        }



        .categ {
            color: white;
            text-align: center;
        }

        form {
            text-align: center;
            margin-top: 20px;
        }

        button {
            background-color: #4CAF50;
            /* Green - signifies action/go */
            color: white;
            padding: 10px 20px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #45a049;
        }

        .alert {
            color: #d8000c;
            /* Red - Alert color */
            background-color: #ffbaba;
            border-color: #d8000c;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid transparent;
            border-radius: 4px;
            text-align: center;
        }

        .block {
            border: 1px solid #000;
            padding: 20px;
            margin-top: 10px;
        }


        .bracket {
            display: flex;
            flex-direction: row;
            align-items: center;
        }

        .stage {
            margin: 0 20px;
        }

        .stage:first-of-type {
            margin: 0 20px 50px;
        }

        .table {
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .table th,
        .table td {
            border: 1px solid #e0e0e0;
            padding: 10px 15px;
            text-align: center;


        }

        td {
            border: 1px solid #ccc;
            padding: 10px;
            background-color: #eee;
        }

        .table th {
            background-color: #f0f0f0;
            color: #333;
        }

        /* Connection lines */
        .connector {
            position: relative;
            width: 20px;
            flex-grow: 1;
            flex-shrink: 0;
        }

        .connector:before {
            top: 50%;
            left: 100%;
            width: 20px;
        }

        .connector:after {
            top: 100%;
            left: 50%;
            width: 100%;
            transform: translateX(-50%);
        }

        .final-connector {
            width: 0;
        }

        .final-connector:after {
            border-left: 2px solid #333;
            top: 0;
            left: 0;
            height: 50%;
            transform: none;
        }

        h1 {
            color: white
        }

        header {
            background-color: black;

        }

        a {
            color: white
        }
    </style>
</head>

<body>

    <div class='container'>
        <h1 class='categ'> <a href="turnir.php">Категории турниров</a> | <a href='One-vs-One.php'>Сервера</a> |
            Турнирные сетки</h1>

        <button onclick="switchBlock('block1')">Луций</button>
        <button onclick="switchBlock('block2')">Корвус</button>
        <button onclick="switchBlock('block3')">Фанем</button>
        <button onclick="switchBlock('block4')">Шаеда</button>
        <button onclick="switchBlock('block5')">Ифнир</button>
        <button onclick="switchBlock('block6')">Ксанатос</button>
        <button onclick="switchBlock('block7')">Тарон</button>
        <button onclick="switchBlock('block8')">Рейвен</button>
        <button onclick="switchBlock('block9')">Нагашар</button>


        <div id="block1" class="block">
            <div class="bracket">
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result = mysqli_query($connect, "SELECT * FROM `participants` WHERE `server` = 'Ифнир';");
                            $participations = mysqli_fetch_all($participations_result);

                            for ($i = 0, $c = 1; $i < count($participations); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations)) {
                                    echo "<tr><td>" . $participations[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table><br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participants` WHERE `server` = 'Ифнир' AND (`score` = 2 OR `score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participants` WHERE `server` = 'Ифнир' AND (`score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participants` WHERE `server` = 'Ифнир' AND (`score` = 6 OR `score` = 8);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div id="block2" class="block" style="display: none;">
            <div class="bracket">
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Корвус';");
                            $participations = mysqli_fetch_all($participations_result);

                            for ($i = 0, $c = 1; $i < count($participations); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations)) {
                                    echo "<tr><td>" . $participations[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table><br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Корвус' AND (`score` = 2 OR `score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Корвус' AND (`score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Корвус' AND (`score` = 6 OR `score` = 8);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div id="block3" class="block" style="display: none;">
            <div class="bracket">
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Фанем';");
                            $participations = mysqli_fetch_all($participations_result);

                            for ($i = 0, $c = 1; $i < count($participations); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations)) {
                                    echo "<tr><td>" . $participations[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table><br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Фанем' AND (`score` = 2 OR `score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Фанем' AND (`score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Фанем' AND (`score` = 6 OR `score` = 8);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div id="block4" class="block" style="display: none;">
            <div class="bracket">
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Шаеда';");
                            $participations = mysqli_fetch_all($participations_result);

                            for ($i = 0, $c = 1; $i < count($participations); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations)) {
                                    echo "<tr><td>" . $participations[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table><br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Шаеда' AND (`score` = 2 OR `score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Шаеда' AND (`score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Шаеда' AND (`score` = 6 OR `score` = 8);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div id="block5" class="block" style="display: none;">
            <div class="bracket">
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Ифнир';");
                            $participations = mysqli_fetch_all($participations_result);

                            for ($i = 0, $c = 1; $i < count($participations); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations)) {
                                    echo "<tr><td>" . $participations[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table><br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Ифнир' AND (`score` = 2 OR `score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Ифнир' AND (`score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Ифнир' AND (`score` = 6 OR `score` = 8);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div id="block6" class="block" style="display: none;">
            <div class="bracket">
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Ксанатос';");
                            $participations = mysqli_fetch_all($participations_result);

                            for ($i = 0, $c = 1; $i < count($participations); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations)) {
                                    echo "<tr><td>" . $participations[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table><br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Ксанатос' AND (`score` = 2 OR `score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Ксанатос' AND (`score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Ксанатос' AND (`score` = 6 OR `score` = 8);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div id="block7" class="block" style="display: none;">
            <div class="bracket">
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Тарон';");
                            $participations = mysqli_fetch_all($participations_result);

                            for ($i = 0, $c = 1; $i < count($participations); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations)) {
                                    echo "<tr><td>" . $participations[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table><br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Тарон' AND (`score` = 2 OR `score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Тарон' AND (`score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Тарон' AND (`score` = 6 OR `score` = 8);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div id="block8" class="block" style="display: none;">
            <div class="bracket">
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Рейвен';");
                            $participations = mysqli_fetch_all($participations_result);

                            for ($i = 0, $c = 1; $i < count($participations); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations)) {
                                    echo "<tr><td>" . $participations[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table><br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Рейвен' AND (`score` = 2 OR `score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Рейвен' AND (`score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Рейвен' AND (`score` = 6 OR `score` = 8);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div id="block9" class="block" style="display: none;">
            <div class="bracket">
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Нагашар';");
                            $participations = mysqli_fetch_all($participations_result);

                            for ($i = 0, $c = 1; $i < count($participations); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations)) {
                                    echo "<tr><td>" . $participations[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table><br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Нагашар' AND (`score` = 2 OR `score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Нагашар' AND (`score` = 4 OR `score` = 6);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="stage">
                        <div class="group-stage">

                            <?php
                            $participations_result_two = mysqli_query($connect, "SELECT * FROM `participations` WHERE `server` = 'Нагашар' AND (`score` = 6 OR `score` = 8);");

                            $participations_two = mysqli_fetch_all($participations_result_two);

                            for ($i = 0, $c = 1; $i < count($participations_two); $i += 2) {
                                echo "<br><table>";
                                echo "<tr><th colspan='2'>Группа " . $c++ . "</th></tr>";
                                echo "<tr><td>" . $participations_two[$i][1] . "</td></tr>";
                                if ($i + 1 < count($participations_two)) {
                                    echo "<tr><td>" . $participations_two[$i + 1][1] . "</td></tr>";
                                }
                                echo "</table> <br>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

            </div>
        </div>



    </div>
    <script>
        function switchBlock(blockId) {
            // First hide all blocks
            var blocks = document.querySelectorAll('.block');
            for (var i = 0; i < blocks.length; i++) {
                blocks[i].style.display = 'none';
            }

            // Then show the requested block using the passed blockId
            var blockToShow = document.getElementById(blockId);
            blockToShow.style.display = 'block';
        }
    </script>
    <?php require_once 'footer.php' ?>
</body>

</html>