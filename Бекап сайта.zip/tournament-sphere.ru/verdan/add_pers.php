<?php
session_start();
require_once "connect.php";

// Set the maximum number of characters
$maxCharacters = 6;

// Initialize the error message
$errorMsg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $server = $_POST['server'];
    $nick = $_POST['nick'];
    $id = $_POST['id'];
    $class = $_POST['class'];



    // Check if the nickname already exists on the server for the user
    $sql = "SELECT COUNT(*) AS num_duplicates FROM characters WHERE nickname = '$nick' AND server = '$server'";
    $result = mysqli_query($connect, $sql);
    $row = mysqli_fetch_assoc($result);
    $numDuplicates = $row['num_duplicates'];

    if ($numDuplicates > 0) {
        $_SESSION['message'] = "Персонаж с никнеймом '$nick' уже существует на сервере '$server'.";
        header("Location: ../profile.php");
        die();
    } else {
        // Check if the user has reached the maximum number of characters
        $sql = "SELECT COUNT(*) AS num_characters FROM characters WHERE id_users = '$id'";
        $result = mysqli_query($connect, $sql);
        $row = mysqli_fetch_assoc($result);
        $numCharacters = $row['num_characters'];

        if ($numCharacters >= $maxCharacters) {
            $_SESSION['message'] = "Вы уже создали максимальное количество персонажей.";
            header("Location: ../profile.php");
            die();
        } else {
            // Check if the user already has a character on the selected server
            $sql = "SELECT COUNT(*) AS num_server_characters FROM characters WHERE id_users = '$id' AND server = '$server'";
            $result = mysqli_query($connect, $sql);
            $row = mysqli_fetch_assoc($result);
            $numServerCharacters = $row['num_server_characters'];


            // Add the data to the "characters" table
            $sql = "INSERT INTO characters (id_users, class, server, nickname) VALUES ('$id', '$class', '$server', '$nick')";

            if (mysqli_query($connect, $sql)) {
                $_SESSION['message'] = "Персонаж '$nick' успешно добавлен.";
                header("Location: ../profile.php");
                die();
            } else {
                $_SESSION['message'] = "Произошла непредвиденная ошибка.";
                header("Location: ../profile.php");
                die();
            }
        }
    }
}
