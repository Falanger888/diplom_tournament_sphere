<?php
session_start();
require_once "connect.php";
if (isset($_POST['login'])) {
    $team = $_POST['team'];
    $new_team_name = $_POST["login"];



    if (empty($new_team_name)) {
        $_SESSION['message1'] = 'Название команды не может быть пустым.';
        header('Location: ../my_team.php');
        exit;
    }

    // Проверка уникальности логина
    $sql = "SELECT * FROM `team` WHERE name = '$new_team_name'";
    $result = $connect->query($sql);

    // Проверка наличия записей с новым именем команды
    if ($result->num_rows == 0) {
        // Обновление имени команды
        $update_sql = "UPDATE `team` SET name = '$new_team_name' WHERE name = '$team'";
        $connect->query($update_sql);
        $_SESSION['message1'] = 'Название изменено.';
        header('Location: ../my_team.php');
        exit;
    }
    $_SESSION['message1'] = 'Такое название занято.';
}

header('Location: ../my_team.php');
exit;
?>