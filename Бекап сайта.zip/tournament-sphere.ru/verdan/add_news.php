<?php
session_start();

require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $avatar = $_FILES['avatar'];

    // Проверка, был ли загружен файл
    if ($avatar['error'] === UPLOAD_ERR_OK) {
        // Создание нового имени файла
        $filename = uniqid() . '_' . $avatar['name'];

        // Путь для сохранения файла
        $destination = '../img/news/' . $filename;

        // Сохранение файла
        if (move_uploaded_file($avatar['tmp_name'], $destination)) {
            // Полный адрес файла
            $fileUrl = 'img/news/' . $filename;

            // Передача данных в таблицу News
            $newsQuery = "INSERT INTO news (`img`, `title`, `description`) VALUES ('$fileUrl', '$title', '$description' )";
            $connect->query($newsQuery);

            $_SESSION['message'] = "Успешно";
            header("Location: ../news.php");
            exit();
        } else {
            $_SESSION['message'] = "Ошибка при сохранении файла";
            header("Location: ../news.php");
            exit();
        }
    } else {
        // Установка значения по умолчанию для изображения
        $fileUrl = 'img/news/news_2.png';

        // Передача данных в таблицу News
        $newsQuery = "INSERT INTO news (`img`, `title`, `description`) VALUES ('$fileUrl', '$title', '$description' )";
        $connect->query($newsQuery);

        $_SESSION['message'] = "Успешно";
        header("Location: ../news.php");
        exit();
    }
} else {
    $_SESSION['message'] = "Такого кода нет";
    header("Location: ../news.php");
    exit();
}
?>