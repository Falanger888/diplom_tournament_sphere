<?php
session_start();

require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['news_id'];

    // Проверка, является ли пользователь администратором
    if (isset($_SESSION["user"])) {
        // Удаление записи из таблицы News
        $deleteQuery = "DELETE FROM news WHERE id = '$id'";
        $connect->query($deleteQuery);

        $_SESSION['message'] = "Запись успешно удалена";
        header("Location: ../news.php");
        exit();
    } else {
        $_SESSION['message'] = "Недостаточно прав для удаления записи";
        header("Location: ../news.php");
        exit();
    }
} else {
    $_SESSION['message'] = "Некорректный метод запроса";
    header("Location: ../news.php");
    exit();
}
