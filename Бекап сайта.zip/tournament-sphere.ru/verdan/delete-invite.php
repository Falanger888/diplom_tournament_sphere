<?php
session_start();
require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $login = $_POST['login'];


    // Получение идентификатора пользователя по логину
    $user_query = "DELETE FROM `notifications` WHERE `id` = $id and `login`='$login'";
    $user_result = $connect->query($user_query);
    header("Location: ../my_team.php");
    exit();

}