<?php
session_start();
require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $team = $_POST['team_name'];
  $avatarDestination = 'img/team/team.png';
  $id_user = $_SESSION['user']['id']; // Получение значения id_user из сессии
  $rol = 'captain';


  if (!empty($_FILES['avatar'])) {
    $avatarPath = '../img/team/';
    $avatarExtension = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
    $avatarName = uniqid() . '.' . $avatarExtension;
    $savePath = $avatarPath . $avatarName;


    // Проверка успешной загрузки файла
    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $savePath)) {
      $avatarDestination = 'img/team/' . $avatarName;
    } else {
      // Ошибка загрузки файла
      // Можно вывести сообщение об ошибке или выполнить другие действия
    }
  } else {
    // Файл не был загружен
    $avatarDestination = 'img/team/team.png'; // Установка значения по умолчанию
  }
  // Проверка наличия логина в таблице team
  $checkTeamQuery = "SELECT * FROM team WHERE `name` = '$team' and `rol`='captain'";
  $teamResult = $connect->query($checkTeamQuery);

  if (!$teamResult) {
    // Ошибка выполнения запроса
    die("Ошибка при выполнении запроса: " . $connect->error);
  }

  if ($teamResult->num_rows > 0) {
    $_SESSION['message'] = "Команда с таким названием уже есть.";
    header('location: ../create_team.php');
    exit;
  }

  // Вставка данных в базу данных
  $stmt = $connect->prepare("INSERT INTO `team` (`id_user`, `name`, `img`, `rol`) VALUES (?, ?, ?, ?)");
  $stmt->bind_param("isss", $id_user, $team, $avatarDestination, $rol);

  $stmt->execute();
  $stmt->close();
  $connect->close();
  header('location: ../my_team.php');
}