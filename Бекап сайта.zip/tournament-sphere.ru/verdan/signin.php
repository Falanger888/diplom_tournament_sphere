<?php
session_start();
require_once "connect.php";

$login = $_POST["login"] ?? '';
$password = $_POST["password"] ?? '';

// Проверка, чтобы пароль не был пустым
if (empty($password)) {
    $_SESSION['message'] = 'Введите пароль';
    header('Location: ../Authorization.php');
    exit();
}

// Подготовленный запрос для защиты от SQL-инъекций
$check_user = $connect->prepare("SELECT * FROM `users` WHERE `login` = ?");
$check_user->bind_param("s", $login);
$check_user->execute();
$result = $check_user->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    // Проверка, чтобы пароль был хеширован при регистрации
    if (!password_verify($password, $user['password'])) {
        $_SESSION['message'] = 'Неверный логин или пароль';
        header('Location: ../Authorization.php');
        exit();
    }

    // Получение значения роли из базы данных
    $rol = $user['rol'];

    $_SESSION["user"] = [
        "rol" => $rol,
        "login" => $user["login"],
        "id" => $user["id"],
    ];

    header('Location: ../profile.php');
    exit();
} else {
    $_SESSION['message'] = 'Неверный логин или пароль';
    header('Location: ../Authorization.php');
    exit();
}