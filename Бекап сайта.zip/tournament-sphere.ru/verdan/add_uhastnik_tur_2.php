<?php
session_start();

require_once "connect.php";

if (isset($_POST['selected_characters'])) {

    // Получаем значения cat и server из формы
    $cat = $_POST['cat'];
    $server = $_POST['server'];

    // Получаем массив выбранных персонажей из формы
    $selected_characters = $_POST['selected_characters'];

    // Подготавливаем запрос на вставку данных в базу данных
    $stmt = $connect->prepare("INSERT INTO participants (id_haracters, id_user, cat, server) VALUES (?, ?, ?, ?)");

    if ($stmt === false) {
        die('Ошибка подготовки запроса: ' . $connect->error);
    }

    // Подготавливаем запрос на проверку наличия записи в базе данных
    $check_stmt = $connect->prepare("SELECT id FROM participants WHERE id_user = ? AND cat = ? AND server = ?");

    if ($check_stmt === false) {
        die('Ошибка подготовки запроса: ' . $connect->error);
    }

    $check_stmt->bind_param("sss", $id_user, $cat, $server);

    // Проходим по выбранным персонажам и проверяем наличие записи перед вставкой
    foreach ($selected_characters as $id_user => $characters) {
        foreach ($characters as $character_id => $value) {
            $id_user = $id_user;
            $cat = $cat;
            $server = $server;

            // Выполняем запрос на проверку
            $check_stmt->execute();
            $check_stmt->store_result();

            // Если запись уже существует, устанавливаем сообщение и перенаправляем
            if ($check_stmt->num_rows > 0) {
                $_SESSION['message2'] = "Один из участников или вы уже учавствуете.";
                $_SESSION['cat_tur'] = $_POST['cat'];
                $_SESSION['server'] = $_POST['server'];
                header("Location: ../server_table.php"); // Перенаправляем на страницу с ошибкой
                exit();
            } else {
                // Если запись не существует, вставляем данные в базу данных
                $stmt->bind_param("ssss", $character_id, $id_user, $cat, $server);
                $stmt->execute();
            }
        }
    }

    // Закрываем подготовленные выражения
    $check_stmt->close();
    $stmt->close();

    $_SESSION['message2'] = "Один из участников или вы уже учавствуете.";
    $_SESSION['cat_tur'] = $_POST['cat'];
    $_SESSION['server'] = $_POST['server'];
    header("Location: ../server_table.php"); // Перенаправляем на страницу с ошибкой
    exit();
} else {
    $_SESSION['message2'] = "Ошибка обратитесь в поддержку.";
    $_SESSION['cat_tur'] = $_POST['cat'];
    $_SESSION['server'] = $_POST['server'];
    header("Location: ../server_table.php"); // Перенаправляем на страницу с ошибкой
    exit();
}
?>