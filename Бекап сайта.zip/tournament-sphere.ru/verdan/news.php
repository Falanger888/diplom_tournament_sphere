<?php
require_once "connect.php";

// Выполнение SQL-запроса для получения данных из таблицы "news"
$query = "SELECT * FROM `news` ORDER BY `id` DESC";
$result = mysqli_query($connect, $query);

// Проверка наличия данных
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Вывод данных
        $image = $row['img'];
        $title = $row['title'];
        $description = $row['description'];
        $newsId = $row['id']; // Получение id новости

        // Вывод полученных данных в HTML-разметку
        echo '
        <div class="news">
            <div>
                <img src="' . $image . '" alt="">
            </div>
            <div class="news-content">
                <p>' . $title . '</p>
                <p>' . $description . '</p>
            </div>';

        // Проверка, является ли пользователь администратором
        if (isset($_SESSION["user"]) && $_SESSION["user"]["rol"] == "admin") {
            // Форма для удаления новости
            echo '
            <form class="admin-form" action="verdan/delete_news.php" method="POST">
                <input type="hidden" name="news_id" value="' . $newsId . '">
                <button class="delete_news" type="submit">Удалить новость</button>
            </form>';
        }

        echo '</div>'; // Закрываем div для новости

        echo '</div><br>'; // Закрываем div для блока новости
    }
} else {

}

// Закрытие соединения с базой данных
mysqli_close($connect);
?>