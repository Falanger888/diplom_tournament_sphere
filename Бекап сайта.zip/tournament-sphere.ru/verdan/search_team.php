<?php
session_start();

require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $team = $_POST['team'];
    $id = $_SESSION['user']['id'];

    // Проверка наличия команды в столбце name таблицы team
    $sql_check_team = "SELECT id_user FROM team WHERE name = '$team'";
    $result_check_team = $connect->query($sql_check_team);

    if ($result_check_team->num_rows > 0) {
        // Получение id_user с ролью captain
        $sql_get_captain = "SELECT users.id, users.login 
                            FROM team 
                            INNER JOIN users ON team.id_user = users.id 
                            WHERE team.name = '$team' AND team.rol = 'captain'";
        $result_get_captain = $connect->query($sql_get_captain);

        if ($result_get_captain->num_rows > 0) {
            // Внесение данных в таблицу team_search
            while ($row = $result_get_captain->fetch_assoc()) {
                $captainId = $row['id'];
                $captainLogin = $row['login'];

                $sql_insert_team_search = "INSERT INTO team_search (name, login, captain) VALUES ('$team', '$id', '$captainLogin')";
                $connect->query($sql_insert_team_search);
            }

            header('Location: ../waiting_page.php');
            exit();
        } else {
            $_SESSION['message'] = 'Такой команды не найдено.';
            header('Location: ../search_team.php');
            exit();
        }
    } else {
        $_SESSION['message'] = 'Такой команды не найдено.';
        header('Location: ../search_team.php');
        exit();
    }
}
?>