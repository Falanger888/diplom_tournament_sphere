<?php


session_start();
require_once "connect.php";


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_user = $_POST['id'];
    $description = $_POST['description'];


    $sql = "INSERT INTO help (`id_user`, `description`) VALUES ('$id_user', ' $description')";

            if (mysqli_query($connect, $sql)) {
                $_SESSION['message'] = "В скором времени, вам ответят.";
                header("Location: ../profile.php");
                die();
            } else {
                $_SESSION['message'] = "Произошла непредвиденная ошибка.";
                header("Location: ../profile.php");
                die();
            }



   
    
}