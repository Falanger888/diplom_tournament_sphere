<?php
session_start();
require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'];
    $team = $_POST['team_name'];
    $text = 'Вас пригласили в команду ' . $team . '. Подумайте об этом предложении';

    // Получение идентификатора пользователя по логину
    $user_query = "SELECT id FROM users WHERE login = '$login'";
    $user_result = $connect->query($user_query);

    if ($user_result && $user_result->num_rows > 0) {
        $user_row = $user_result->fetch_assoc();
        $id_user = $user_row['id'];

        // Проверка наличия участника в команде по id_user и названию команды
        $check_query = "SELECT * FROM team WHERE id_user = '$id_user' AND name = '$team'";
        $check_result = $connect->query($check_query);

        if ($check_result && $check_result->num_rows > 0) {
            $_SESSION['message'] = 'Такой участник уже существует в команде.';
            header("Location: ../my_team.php");
            exit();
        }

        // Проверка наличия команды у приглашеного
        $check_query = "SELECT * FROM team WHERE id_user = '$id_user'";
        $check_result = $connect->query($check_query);

        if ($check_result && $check_result->num_rows > 0) {
            $_SESSION['message'] = 'У этого игрока уже есть команда.';
            header("Location: ../my_team.php");
            exit();
        }


        // Проверка наличия отправленного приглашения игроку с совпадающим ником и командой
        $invite_query = "SELECT * FROM notifications WHERE login = '$login' AND name = '$team'";
        $invite_result = $connect->query($invite_query);

        if ($invite_result && $invite_result->num_rows > 0) {
            $_SESSION['message'] = 'Приглашение уже отправлено этому игроку.';
            header("Location: ../my_team.php");
            exit();
        }

        // Вставка данных в базу данных
        $insert_query = "INSERT INTO `notifications` (`id`, `login`, `description`, `name`) VALUES (NULL, '$login', '$text', '$team')";

        if (mysqli_query($connect, $insert_query)) {
            header("Location: ../my_team.php");
        }
    } else {
        $_SESSION['message'] = 'Пользователь с таким логином не найден.';
        header("Location: ../my_team.php");
        exit();
    }
}
?>