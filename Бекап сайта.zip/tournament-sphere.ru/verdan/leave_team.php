
<?php
session_start();
require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['userId'];




    // Получение идентификатора пользователя по логину
    $user_query = "DELETE FROM `team` WHERE `id_user` = $id";
    $user_result = $connect->query($user_query);
    header("Location: ../my_team.php");
    exit();

}