<?php
session_start();
require_once "connect.php";
require_once 'phpmailer/PHPMailerAutoload.php';

$mail = new PHPMailer;
$mail->CharSet = 'utf-8';
$randomNumber = mt_rand(100000, 999999);
$code = $randomNumber;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $login = $_POST['login'];
  $email = $_POST['email'];
  $nick = $_POST['nick'];
  $server = $_POST['server'];
  $class = $_POST['class'];
  $password = $_POST['password'];
  $config_password = $_POST['config_password'];
  $avatarDestination = 'img/users/user.png';

  // Проверка наличия файла
  if (!empty($_FILES['avatar'])) {
    $avatarPath = '../img/users/';
    $avatarExtension = pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION);
    $avatarName = uniqid() . '.' . $avatarExtension;
    $savePute = $avatarPath . $avatarName;


    // Проверка успешной загрузки файла
    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $savePute)) {
      $avatarDestination = 'img/users/' . $avatarName;
    } else {
      // Ошибка загрузки файла
    }
  } else {
    // Файл не был загружен
    $avatarDestination = ''; // Установка пустого значения, чтобы избежать ошибки
  }



  // Проверка наличия логина в таблице Users
  $checkLoginQuery = "SELECT * FROM users WHERE login = '$login'";
  $loginResult = $connect->query($checkLoginQuery);

  if ($loginResult->num_rows > 0) {
    $_SESSION['message'] = "Такой логин уже занят";
    header('location: ../Register.php');
    exit;
  }

  // Проверка наличия электронной почты в таблице Users
  $checkEmailQuery = "SELECT * FROM users WHERE email = '$email'";
  $emailResult = $connect->query($checkEmailQuery);

  if ($emailResult->num_rows > 0) {
    $_SESSION['message'] = "Такая почта уже используется";
    header('location: ../Register.php');
    exit;
  }

  // Проверка наличия никнейма в таблице characters
  $checkNicknameQuery = "SELECT * FROM characters WHERE nickname = '$nick'";
  $nicknameResult = $connect->query($checkNicknameQuery);

  if ($nicknameResult->num_rows > 0) {
    $_SESSION['message'] = "Такой Никнейм уже занят";
    header('location: ../Register.php');
    exit;
  }

  // Хеширование пароля
  $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

  // Вставка данных в базу данных
  $stmt = $connect->prepare("INSERT INTO `temporaryusers` (`avatar`, `email`,`login`, `nickname`, `server`, `class`, `password`, `code`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  $stmt->bind_param("ssssssss", $avatarDestination, $email, $login, $nick, $server, $class, $hashedPassword, $code);
  $stmt->execute();


  // Отправка письма подтверждения
  $mail->isSMTP();
  $mail->Host = 'smtp.mail.ru';
  $mail->SMTPAuth = true;
  $mail->Username = 'tournament-spheremail-aa@mail.ru';
  $mail->Password = 'Raq8JhNVTSdjD4iyJgNH';
  $mail->SMTPSecure = 'ssl';
  $mail->Port = 465;
  $mail->setFrom('tournament-spheremail-aa@mail.ru');
  $mail->addAddress($email);
  $mail->isHTML(true);
  $mail->Subject = 'Турнирная сфера ArcheAge';
  $mail->Body = '
  <html>
    <head>
      <style>
        /* Стили для улучшения внешнего вида приглашения */
        body {
          font-family: Arial, sans-serif;
          background-color: #f5f5f5;
          color: #333333;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          padding: 20px;
          background-color: #ffffff;
          border-radius: 5px;
          box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h1 {
          color: #ff6600;
        }
        p {
          margin-bottom: 20px;
        }
        .code {
          font-weight: bold;
          color: #ff6600;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>Турнирная сфера ArcheAge</h1>
        <p>Здравствуйте, ' . $login . ',</p>
        <p>Это письмо отправлено вам, чтобы подтвердить ваш email для участия в турнирах.</p>
        <p>Введите сгенерированное число на странице для активации вашего email: <span class="code">' . $code . '</span></p>
        <p>Если вы не ожидали получить это письмо, просто проигнорируйте его.</p>
      </div>
    </body>
  </html>
';
  $mail->isHTML(true);
  $mail->AltBody = '';
  if (!$mail->send()) {
    echo 'Error';
  } else {
    header('location: ../confirm_email.php');
    exit;
  }
}



$connect->close();
