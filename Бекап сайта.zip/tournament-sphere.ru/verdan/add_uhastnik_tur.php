<?php
session_start();

require_once "connect.php";


// Проверяем, выбрал ли пользователь персонажа
if (empty($_POST['character'])) {
    echo "<script>alert('Выберите персонажа для участия.');</script>";
    $_SESSION['cat_tur'] = $_POST['cat'];
        $_SESSION['server'] = $_POST['server'];
    echo "<script>window.location.href = '../server_table.php'</script>";
    return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $character = $_POST['character'];
    $id_user = $_POST['id_user'];
    $cat = $_POST['cat'];
    $server = $_POST['server'];

    // Check for duplicate entry based on id_user, cat, and server
    $stmt_check = $connect->prepare("SELECT * FROM participants WHERE id_user = ? AND cat = ? AND server = ?");
    $stmt_check->bind_param("sss", $id_user, $cat, $server);
    $stmt_check->execute();
    $result = $stmt_check->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['message2'] = "Вы уже зарегестрировались на этом сервере.";
        $_SESSION['cat_tur'] = $_POST['cat'];
        $_SESSION['server'] = $_POST['server'];
        header("Location: ../server_table.php");
        exit();
    }

    // If no duplicate entry, insert the new record
    $stmt = $connect->prepare("INSERT INTO participants (id_haracters, id_user, cat, server) VALUES (?, ?, ?, ?)");
    if ($stmt === false) {
        die('Ошибка подготовки запроса: ' . $connect->error);
    }
    
    $stmt->bind_param("ssss", $character, $id_user, $cat, $server);
    if ($stmt === false) {
        die('Ошибка привязки параметров: ' . $stmt->error);
    }
    
    $result = $stmt->execute();
    if ($result === false) {
        die('Ошибка выполнения запроса: ' . $stmt->error);
    }

    // Pass data to server_table.php
    $_SESSION['cat_tur'] = $_POST['cat'];
    $_SESSION['server'] = $_POST['server'];

    $_SESSION['message2'] = "Вы теперь участвуете, удачи!";
    header("Location: ../server_table.php");
    exit();
}
?>