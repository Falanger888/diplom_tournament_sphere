<?php
session_start();

require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nick = $_POST['nick'];
    $server = $_POST['server'];

    $login = $_SESSION['user']['login'];

    $sql = "SELECT * FROM users WHERE login = '$login'";
    $result = $connect->query($sql);
    $row = $result->fetch_assoc();


    // Получение id пользователя
    $userID = $row['id'];
    // Delete the record from the "characters" table
    $sql = "DELETE FROM characters WHERE nickname = '$nick' and `server`='$server'";
    if (mysqli_query($connect, $sql)) {
        $_SESSION['message'] = "Персонаж " . $nick . " успешно удален! На сервере " . $server . ".";
        header("Location: ../profile.php");
    } else {
        $_SESSION['message'] = "Ошибочка";
        header("Location: ../profile.php");
    }
}
