<?php
session_start();
require_once "connect.php";

$id = $_SESSION['user']['id'];

// Находим логин пользователя по его идентификатору в таблице users
$user_query = "SELECT login FROM users WHERE id = '$id'";
$user_result = $connect->query($user_query);

if ($user_result && $user_result->num_rows > 0) {


    // Удаляем запись из таблицы team_search по логину пользователя
    $delete_query = "DELETE FROM team_search WHERE `login`= $id";
    $delete_result = $connect->query($delete_query);

    if ($delete_result) {
        header("Location: ../team.php");
        exit();
    } else {
        // Обработка ошибки удаления
        echo "Ошибка удаления записи из таблицы team_search";
    }
} else {
    // Обработка ошибки поиска пользователя
    echo "Пользователь с данным идентификатором не найден";
}
