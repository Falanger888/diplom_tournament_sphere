<?php
session_start();
require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['userId'];
    $team = $_POST['team'];

    // Получение информации о пользователе, который передает роль капитана
    $user_query = "SELECT * FROM `team` WHERE `id_user` = $id AND `name` = '$team'";
    $user_result = $connect->query($user_query);
    $user = $user_result->fetch_assoc();


    if ($user['rol'] == 'captain') {
        // Получение всех участников определенной команды, у которых роль не капитан
        $team_query = "SELECT * FROM `team` WHERE `rol` != 'captain' AND `name` = '$team'";
        $team_result = $connect->query($team_query);
        $team_members = $team_result->fetch_all(MYSQLI_ASSOC);

        if (count($team_members) > 0) {
            // Выбор случайного участника из команды
            $random_member = $team_members[array_rand($team_members)];

            // Обновление роли случайного участника на капитана
            $update_query = "UPDATE `team` SET `rol` = 'captain' WHERE `id` = " . $random_member['id'];
            $connect->query($update_query);

            // Получение id нового капитана
            $id_new_captan = $random_member['id_user'];


            // Обновление записей в таблице team_game_history
            $update_query = "UPDATE `team_game_history` SET `id_team_captan` =  $id_new_captan WHERE `id_team_captan` = $id";
            $connect->query($update_query);


            // Удаление
            $delete_previous_captain_query = "DELETE FROM `team` WHERE `id_user` = $id";
            $connect->query($delete_previous_captain_query);
        }
        // Обновление записей в таблице team_game_history
        $update_query = "UPDATE `team_game_history` SET `id_team_captan` =  0 WHERE `id_team_captan` = $id";
        $connect->query($update_query);

    }
    $delete_previous_captain_query = "DELETE FROM `team` WHERE `id_user` = $id";
    $connect->query($delete_previous_captain_query);
    header("Location: ../my_team.php");
    exit();
}

