<?php


$connect = mysqli_connect("localhost", "u2396156_Falange", "pM5zQ2iA3mpJ7eW2", "u2396156_archeagesphere");
if (!$connect) {
    die("Ошибка подключения к базе данных");
}
mysqli_set_charset($connect, "utf8");
