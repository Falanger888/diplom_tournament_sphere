<?php
session_start();


require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = $_POST['code'];

    // Получение данных из temporaryusers для указанного кода
    $query = "SELECT `avatar`, `email`, `login`, `nickname`, `server`, `class`, `password` FROM temporaryusers WHERE code = '$code'";
    $result = $connect->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        $avatar = $row['avatar'];
        $email = $row['email'];
        $login = $row['login'];
        $nickname = $row['nickname'];
        $server = $row['server'];
        $class = $row['class'];
        $password = $row['password'];

        // Передача данных в таблицу Users
        $usersQuery = "INSERT INTO users (`login`, `email`, `password`, `avatar`) VALUES ('$login', '$email', '$password', '$avatar')";
        $connect->query($usersQuery);

        // Получение id пользователя, которого только что добавили
        $userId = $connect->insert_id;

        // Передача данных в таблицу characters с использованием внешнего ключа id_users
        $charactersQuery = "INSERT INTO characters (`id_users`, `class`, `server`, `nickname`) VALUES ('$userId', '$class', '$server', '$nickname')";
        $connect->query($charactersQuery);

        // Удаление записей из temporaryusers по логину или почте
        $deleteQuery = "DELETE FROM temporaryusers WHERE login = '$login' OR email = '$email'";
        $connect->query($deleteQuery);

        // Переадресация на другую страницу (замените "другая_страница.php" на нужный URL)
        $_SESSION['message'] = "Успешно";
        header("Location: ../Authorization.php");
        exit();
    } else {
        $_SESSION['message'] = "Такого кода нет";

        // Переадресация на другую страницу
        header("Location: ../confirm_email.php");
        exit();
    }
}

$connect->close();
?>