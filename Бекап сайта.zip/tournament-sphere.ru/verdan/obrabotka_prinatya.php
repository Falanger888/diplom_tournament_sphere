<?php
session_start();
require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = $_POST['result'];
    $id_user = $_POST['id_user'];
    $id_zapros = $_POST['id_zapros'];
    $name_team = $_POST['name'];

    if ($result === "OK" || $result === "Нет") {
        $delete_query = "DELETE FROM team_search WHERE id = '$id_zapros'";
        $delete_result = $connect->query($delete_query);

        if ($delete_result) {
            header("Location: ../profile.php");
        } else {
            echo "Непредвиденная ошибка, обратитесь в поддержку.";
        }
    } else {
        // Первое что делаем - добавляем запись в таблицу team через INSERT INTO
        $insert_query = "INSERT INTO `team` (`id`, `id_user`, `name`, `img`, `rol`) VALUES (NULL, '$id_user', '$name_team', '', ' Participant')";
        $insert_result = $connect->query($insert_query);

        if ($insert_result) {
            // Второе - удаляем запись из таблицы team_search по id_zapros
            $delete_query_team_search = "DELETE FROM team_search WHERE id = '$id_zapros'";
            $delete_result_team_search = $connect->query($delete_query_team_search);

            if ($delete_result_team_search) {
                // Третье - делаем запрос, который добавит данные в таблицу notifications
                $login_query = "SELECT login FROM users WHERE id = '$id_user'";
                $login_result = $connect->query($login_query);
                $login_row = $login_result->fetch_assoc();
                $login = $login_row['login'];

                $notification_query = "INSERT INTO notifications (login, description, name) VALUES ('$login', 'Вы приняты в команду $name_team', 'Система')";
                $notification_result = $connect->query($notification_query);

                if ($notification_result) {
                    // Успешно добавлено, можно добавить дополнительные действия
                } else {
                    echo "Ошибка при добавлении уведомления.";
                }
            } else {
                echo "Ошибка при удалении записи из таблицы team_search.";
            }
        } else {
            echo "Ошибка при добавлении записи в таблицу team.";
        }
    }
    header("Location: ../profile.php");
    exit();
}
