<?php
session_start();
require_once "connect.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = $_POST['result'];
    $id = $_POST['notification_id'];
    $login = $_POST['login'];
    $name = $_POST['name'];
    $id_user = $_SESSION['user']['id'];

    if ($result === "OK" || $result === "Нет") {
        $delete_query = "DELETE FROM notifications WHERE id = '$id'";
        $delete_result = $connect->query($delete_query);

        if ($delete_result) {
            header("Location: ../profile.php");
        } else {
            echo "Непредвиденная ошибка, обратитесь в поддержку.";
        }
    } else {
        $insert_query = "INSERT INTO team (id_user, name, img, rol) VALUES ('$id_user', '$name', '', 'участник')";
        $insert_result = $connect->query($insert_query);

        if ($insert_result) {
            echo "Запись успешно добавлена в таблицу 'team'.";

            // Удаление записи из таблицы 'notifications'
            $delete_notification_query = "DELETE FROM notifications WHERE id = '$id'";
            $delete_notification_result = $connect->query($delete_notification_query);

            if ($delete_notification_result) {
                header("Location: ../profile.php");
            } else {
                echo "Непредвиденная ошибка, обратитесь в поддержку.";
            }
        } else {
            echo "Непредвиденная ошибка, обратитесь в поддержку.";
        }
    }
}
?>