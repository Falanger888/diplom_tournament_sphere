<?php

session_start();
require_once "../connect.php";

if (isset($_POST['login'])) {
  $login = $_POST['login'];
  $id = $_SESSION["user"]['id'];


  // Проверка уникальности логина
  $sql = "SELECT COUNT(*) FROM users WHERE login='$login'";
  $result = $connect->query($sql);
  $login_count = $result->fetch_row()[0];

  // Проверка длины логина
  $login_length = strlen($login);

  // Проверка наличия в логине только букв
  $login_pattern = '/^[a-zA-Zа-яА-Я]+$/';

  // Если логин не уникален
  if ($login_count > 0) {
    $_SESSION['message'] = 'Такой логин уже занят.';
    header('Location: ../../profile.php');
    exit;
  }
  // Если длина логина меньше 3 символов
  elseif ($login_length < 3) {
    $_SESSION['message'] = 'Логин должен быть минимум из трех букв';
    header('Location: ../../profile.php');
    exit;
  }
  // Если логин содержит не только буквы
  elseif (!preg_match($login_pattern, $login)) {
    $_SESSION['message'] = 'Некоректный логин (числа и символы не должны присутствовать).';
    header('Location: ../../profile.php');
    exit;
  }

  // Если есть ошибки, то перенаправление пользователя на страницу профиля
  if (!empty($_SESSION['message'])) {
    header('Location: ../../profile.php');
    exit;
  }

  // Если проверки проходит сделать update в бд в таблице users по id
  $sql = "UPDATE users SET login='$login' WHERE id='$id'";
  $result = $connect->query($sql);

  if ($result) {
    $_SESSION['message'] = 'Логин успешно изменен.';
    header('Location: ../../profile.php');
    exit;
  } else {
    $_SESSION['message'] = 'Логин не изменен. Попробуйте еще раз.';
    header('Location: ../../profile.php');
    exit;
  }
}