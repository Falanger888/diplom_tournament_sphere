<?php
session_start();

require_once "../connect.php";

// Проверяем, был ли отправлен файл
if (isset($_FILES['avatar'])) {
    $file = $_FILES['avatar'];
    $id = $_SESSION["user"]['id'];

    // Проверяем наличие ошибок при загрузке файла
    if ($file['error'] === UPLOAD_ERR_OK) {
        // Проверяем, является ли файл изображением
        $image_info = getimagesize($file['tmp_name']);
        if ($image_info !== false) {
            // Генерируем уникальное имя файла
            $filename = uniqid() . '_' . $file['name'];

            // Перемещаем загруженный файл в папку назначения
            $destination = '../../img/team/' . $filename;
            move_uploaded_file($file['tmp_name'], $destination);

            // Сохраняем информацию о файле в базу данных
            $file_path = 'img/team/' . $filename;

            $query = "UPDATE team SET img='$file_path' WHERE id_user='$id'";
            mysqli_query($connect, $query);

            // Отправляем успешный ответ в формате JSON
            $response = [
                'success' => true,
                'message' => 'Аватарка успешно обновлена',
                'file_path' => $file_path
            ];
            echo json_encode($response);
        } else {
            // Отправляем ошибку в формате JSON, если файл не является изображением
            $response = [
                'success' => false,
                'message' => 'Ошибка при загрузке аватарки: файл не является изображением'
            ];
            echo json_encode($response);
        }
    } else {
        // Отправляем ошибку в формате JSON
        $response = [
            'success' => false,
            'message' => 'Ошибка при загрузке аватарки'
        ];
        echo json_encode($response);
    }
} else {
    // Отправляем ошибку в формате JSON, если файл не был отправлен
    $response = [
        'success' => false,
        'message' => 'Файл аватарки не был отправлен'
    ];
    echo json_encode($response);
}
?>