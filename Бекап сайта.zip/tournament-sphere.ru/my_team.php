<?php
session_start();
require_once "verdan/connect.php";
$id = $_SESSION['user']['id'];

$sql = "SELECT * FROM team WHERE id_user = '$id'";
$result = $connect->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Ваш код для обработки найденной записи
} else {
    // Перенаправление на другую страницу
    header("Location: team.php");
    exit;
}
$rol = $row['rol'];
$team = $row['name'];

$sqli = "SELECT * FROM team WHERE name = '$team' and rol ='captain'";
$resultImg = $connect->query($sqli);
$rowIMG = $resultImg->fetch_assoc();
$id_team_captain = $rowIMG['id_user'];
$img = $rowIMG['img'];


?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Моя команда</title>
    <link rel="stylesheet" href="css/def_body.css">
    <link rel="stylesheet" href="css/my_team.css">
</head>
<style>
.participants>div>p>a {
    color: white;
    text-decoration: none;
    transition: 0.5s;
}

.participants>div>p>a:hover {
    transition: 0.5s;
    color: gray;
}

.messange {
    width: 500px;
    font-size: 24px;
    color: white;
    margin-left: 10px;
}

.button-delete-invate {
    all: unset;
}

.button-delete-invate:hover {
    all: unset;
}

.update_team_button {
    all: unset;
}

.update_team_button:hover {
    all: unset;
    cursor: pointer;
}

.login-input {
    all: unset;
    background-color: rgba(217, 217, 217, 0.4);
    color: white;
    width: 483px;
    margin-top: 10px;
    border: 0;
    border-radius: 11px;
    font-family: 'Montserrat Alternates', sans-serif;
    padding: 5px;
    width: 200px;
}

.save-button {
    all: unset;
}

.save-button:hover {
    all: unset;
    cursor: pointer;
}

.exit_uhastnik {
    all: unset;
    background-color: rgba(217, 217, 217, 0.4);
    color: white;
    border: 0;
    border-radius: 3px;
    font-family: 'Montserrat Alternates', sans-serif;
    padding: 1px;
    height: 30px;
    width: 30px;
    font-size: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: 0.5s;
}

.exit_uhastnik:hover {
    transition: 0.5s;
    scale: 1.1;
}

.exit_me {
    all: unset;
    background-color: rgba(217, 217, 217, 0.4);
    color: white;
    border: 0;
    border-radius: 3px;
    font-family: 'Montserrat Alternates', sans-serif;
    padding: 1px;
    height: auto;
    width: 370px;
    font-size: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: 0.5s;
}

.exit_me:hover {
    transition: 0.5s;
    scale: 1.1;
}

.exit_form {
    margin-top: 100px;
}
</style>

<body>
    <?php
    include "header.php";
    ?>
    <br><br><br><br>
    <div class="main-flex">
        <div class='container-left'>
            <div style='display:flex'>
                <p class='shadow'>Команда</p>
                <?php if ($rol === 'captain'): ?>
                <button class="update_team_button" onclick="toggleEditMode()">
                    <img class="update_profile" src="img/update/update.png" alt="">
                </button>
                <?php endif; ?>
            </div>

            <p class="messange">
                <?php

                if (isset($_SESSION['message1'])) {
                    echo $_SESSION['message1'];
                    unset($_SESSION['message1']); // Очищаем переменную сообщения
                }
                ?>
            </p>
            <div class="team-info">

                <div>

                    <form id="avatarForm" enctype="multipart/form-data">
                        <div class="avatar-container <?php echo ($rol !== 'captain') ? 'ordinary-user' : ''; ?>">
                            <img src='<?php echo $img; ?>' alt="Avatar">
                            <div class="avatar-overlay">
                                <span>Изменить аватар команды</span>
                                <input type="file" id="avatarInput" accept="image/*">
                            </div>
                        </div>
                    </form>

                </div>
                <div class="team-details ">
                    <div>
                        <div style='display:flex;'>
                            <p class='team-name'>
                                <?php echo $team; ?>
                                <input type="hidden" name="team" value="<? echo $team; ?>">
                            </p>
                            <button class="save-button" style="display: none;" onclick="saveProfileChanges()">✔</button>
                        </div>


                        <p>Участники:</p>

                    </div>
                    <?php
                    // Выполнение запроса
                    $sql = "SELECT team.id_user, users.id, users.login FROM team INNER JOIN users ON team.id_user = users.id WHERE team.name = '$team'";
                    $result = $connect->query($sql);

                    // Вывод участников
                    if ($result->num_rows > 0) {
                        echo '<div class="participants scrollable-container-uhastnik">';
                        while ($row = $result->fetch_assoc()) {
                            $userId = $row['id'];
                            $login = $row['login'];
                            echo '<div style="display:flex;"><p><a href="view_user.php?id=' . $userId . '">' . $login . '</a></p>';

                            // Форма с кнопкой "Исключить"
                            if ($rol === 'captain') {
                                echo '<form  action="verdan/exclude_user.php" method="post">';
                                echo '<input type="hidden" name="userId" value="' . $userId . '">';
                                echo '<input type="hidden" name="team" value="' . $team . '">';
                                echo '<input class="exit_uhastnik " type="submit" value="-">';
                                echo '</form>';
                            }
                            echo '</div><br>';
                        }
                        echo '</div>';
                    } else {
                        echo "Участники не найдены.";
                    }
                    ?>

                </div>
            </div>
            <script>
            const avatarContainer = document.querySelector('.avatar-container');
            const avatarOverlay = document.querySelector('.avatar-overlay');
            const avatarInput = document.querySelector('#avatarInput');
            const avatarForm = document.querySelector('#avatarForm');

            if (avatarContainer) {
                avatarContainer.addEventListener('click', () => {
                    if ('<?php echo $rol ?>' === 'captain') {
                        if (avatarInput) {
                            avatarInput.click();
                        }
                    }
                });
            }

            if (avatarInput) {
                avatarInput.addEventListener('change', () => {
                    if ('<?php echo $rol ?>' !== 'captain') {
                        return; // Do not proceed if not a captain
                    }

                    const file = avatarInput.files[0];

                    const formData = new FormData(avatarForm);
                    formData.append('avatar', file);

                    fetch('verdan/update/update_team_img.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                window.location.reload(); // Reload the page
                            } else {
                                alert(data.error);
                            }
                        })
                        .catch(error => {
                            console.error(error);
                            alert('An error occurred while uploading the file.');
                        });
                });
            }
            </script>
            <br>
            <div class="table-info">
                <p class='shadow2'>История игр</p>
                <div class="game-history scrollable-container">
                    <table>
                        <tr>
                            <th>Категория</th>
                            <th>Название</th>
                            <th>Сервер</th>
                            <th>Место</th>
                            <th>Убийств</th>
                            <th>Смертей</th>
                        </tr>
                        <?php
                        // Выполнение запроса
                        $sqli = "SELECT `id_team_captan`,`cat`, `name`, `server`, `mesto`, `ubistv`, `smertey` FROM `team_game_history` WHERE `id_team_captan`='$id_team_captain'";
                        $resulti = $connect->query($sqli);

                        // Вывод участников
                        if ($resulti->num_rows > 0) {
                            echo '<div class="participants scrollable-container-uhastnik">';
                            while ($rowi = $resulti->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $rowi['cat'] . "</td>";
                                echo "<td>" . $rowi['name'] . "</td>";
                                echo "<td>" . $rowi['server'] . "</td>";
                                echo "<td>" . $rowi['mesto'] . "</td>";
                                echo "<td>" . $rowi['ubistv'] . "</td>";
                                echo "<td>" . $rowi['smertey'] . "</td>";
                                echo "</tr>";
                            }
                            echo '</div>'; // Закрываем div для участников
                        } else {
                            // Дополнительный код, если результатов нет
                        }
                        ?>

                    </table>
                </div>
            </div>
        </div>
        <div class='container-right'>
            <p class='shadow1'>Приглашение в команду</p>
            <div class="invate ">
                <div>

                    <P>Пригласите вашего друга в команду</P>
                    <br>
                    <p>Введите логин игрока</p>
                    <form action="verdan/priglos.php" method="POST">
                        <input name="login" type="text">
                        <input name="team_name" type="hidden" value='<? echo $team; ?>'>
                        <button>Готово</button>
                    </form>
                    <p class="messange">
                        <?php

                        if (isset($_SESSION['message'])) {
                            echo $_SESSION['message'];
                            unset($_SESSION['message']); // Очищаем переменную сообщения
                        }
                        ?>
                    </p>
                </div>


            </div>
            <br>
            <p class='shadow3'>Отправленные приглашения</p>
            <div class='invate-history scrollable-container'>
                <?php
                // Выполнение запроса
                $sql_invite = "SELECT * FROM `notifications` where name = '$team'";
                $result_invite = $connect->query($sql_invite);

                // Вывод участников
                if ($result_invite->num_rows > 0) {
                    while ($row = $result_invite->fetch_assoc()) {
                        $login = $row['login'];
                        $id = $row['id']; // Добавлено получение значения id
                        echo '<div class="invate-delete-flex">';
                        echo '<p>' . $login . '</p>';
                        echo '<form class="delete-invate" action="verdan/delete-invite.php" method="POST">';
                        echo '<input type="hidden" name="id" value="' . $id . '">';
                        echo '<input type="hidden" name="login" value="' . $login . '">';
                        echo '<button class="button-delete-invate">-</button></form>';
                        echo '</div>';
                    }
                } else {
                    echo "Ваша команда еще никого не пригласила.";
                }
                ?>

            </div>

            <?php
            // Предположим, что у вас есть переменная $rol, содержащая роль пользователя
            
            if ($rol != 'captain') {
                echo "
        <form class='exit_form' action='verdan/leave_team.php' method='post'>
            <input type='hidden' name='userId' value='$id'>
            <button class='exit_me'>Выйти из команды</button>
            </form>
            ";
            }
            ?>
        </div>

    </div>



    <script>
    var team = "<?php echo $team; ?>";
    </script>

    <script src="js/Update_team.js"></script>
    <!-- <script src="js/my_team.js"></script> -->
    <?php
    include "footer.php";
    ?>
</body>

</html>