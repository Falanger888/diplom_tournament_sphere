<link rel="stylesheet" href="css/footer.css">
<footer>

        <p>© 2023-2024 Сайт по организации турниров ArcheAge. Все права защищены.</p>

    
    <div class='margin-right'>
    <a href="https://vk.com/tournament_sphere" target="_blank">
        <img class='foot_img' src="img/vk.png" alt="vk">
    </a>
    <a href="https://www.youtube.com/channel/UC3-w0_gGWPttE1YfGoqERZg" target="_blank">
        <img class='foot_img' src="img/yuotube.png" alt="youtube">
    </a>
    <a href="https://discord.gg/pg2XTPab7P" target="_blank">
        <img class='foot_img' src="img/dis.png" alt="discord">
    </a>
</div>
<!--АМОГУС-->
</footer>