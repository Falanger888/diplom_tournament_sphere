<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: Authorization.php");
    exit;
}
require_once "verdan/connect.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создание команды</title>
    <link rel="stylesheet" href="css/def_body.css">
    <link rel="stylesheet" href="css/create_team.css">

</head>
<style>
    #teamNameError {
        margin-top: 10px;
    }
    
    
    @media only screen and (max-width: 400px) {

      h1{
          width:300px;
          font-size:24px;
      }
      
      body>div>p{
          width:90%;
      }
      form {
          width:350px;
          margin-left:5px;
      }
      input{
          width:300px;
          font-size:18px;
      }
      .input-file+label {
          width:300px;
      }
      label{
          font-size:20px;
          width:90%;
      }
    }
</style>

<body>
    <?php
    include "header.php";
    ?>
    <h1>Создание команды</h1>
    <div>
        <br>
        <p>При создании команды вы автоматически становитесь лидером</p>
        <br>
        <form action="verdan/create_team.php" method="POST" enctype="multipart/form-data">
            <label for="">Название команды</label>
            <input id="teamName" type="text" name="team_name" required class="input">
            <p class="mesange">
                <?php

                if (isset($_SESSION['message'])) {
                    echo $_SESSION['message'];
                    unset($_SESSION['message']); // Очищаем переменную сообщения
                }
                ?>
            </p>

            <span Style='font-size:14px;' id="teamNameError" style="color: white;"></span>
            <label for="avatar">Выберите аватар для команды</label>
            <input type="file" name="avatar" class="input-file" id="fileInput" />
            <label for="fileInput" id="fileInputLabel">Выберите файл</label>
            <div class="input-file-2" id="selectedFileMessage" style="display: none;">Файл выбран: <span
                    id="fileName"></span></div>
            <button type="submit">Готово</button>
        </form>
    </div>
    <br><br><br><br>
    <?php
    include "footer.php";
    ?>
    <script>


        // Валидация названия команды
        var teamNameInput = document.getElementById('teamName');
        var teamNameError = document.getElementById('teamNameError');
        var lettersRegex = /^[A-Za-zА-Яа-я]+$/;

        teamNameInput.addEventListener('input', function () {
            var teamNameValue = teamNameInput.value;
            if (teamNameValue.length < 3 || !lettersRegex.test(teamNameValue)) {
                teamNameError.textContent = 'Название команды должно состоять из 3 букв';
                teamNameInput.setCustomValidity('Некорректное название команды');
            } else {
                teamNameError.textContent = '';
                teamNameInput.setCustomValidity('');
            }
        });

        // Обработка отправки формы
        var form = document.querySelector('form');
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault(); // Отменяем отправку формы, если она не проходит валидацию
            }
        });

        // Валидация картинки
        var fileInput = document.getElementById('fileInput');
        var fileInputLabel = document.getElementById('fileInputLabel');
        var selectedFileMessage = document.getElementById('selectedFileMessage');
        var fileName = document.getElementById('fileName');

        fileInput.addEventListener('change', function () {
            var file = fileInput.files[0];
            var fileType = file ? file.type : null;

            // Проверяем, является ли файл изображением
            if (file && !fileType.startsWith('image/')) {
                // Если файл не является изображением, сбрасываем выбор файла
                fileInput.value = '';
                selectedFileMessage.style.display = 'none';
                fileName.textContent = '';
                fileInputLabel.textContent = 'Выберите файл (изображение)';
                alert('Пожалуйста, выберите файл в формате изображения.');
            } else {
                selectedFileMessage.style.display = 'block';
                fileName.textContent = file ? file.name : '';
            }
        });

    </script>
</body>

</html>